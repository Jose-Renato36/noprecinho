import { ROTULOS_FONTE, tempoRelativo, dataHora } from '../utils'

export default function SaudeLojas({ lojas = [], resumo }) {
  if (!lojas?.length) {
    return (
      <div className="saas-secao-saude">
        <div className="saas-cabecalho-pagina">
          <div>
            <h2>Diagnóstico & Conectividade dos Scrapers</h2>
            <p className="saas-subtitulo-pagina">
              Painel de telemetria operacional estilo Datadog para monitorar taxa de sucesso, métodos de extração e latência por loja.
            </p>
          </div>
        </div>
        <div className="saas-vazio">
          <div className="saas-vazio__icone">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4.9 19.1C1 15.2 1 8.8 4.9 4.9" />
              <path d="M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5" />
              <circle cx="12" cy="12" r="2" />
              <path d="M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5" />
              <path d="M19.1 4.9C23 8.8 23 15.1 19.1 19" />
            </svg>
          </div>
          <h3>Nenhuma loja com coletas registradas ainda</h3>
          <p>Assim que os scrapers rodarem nas lojas cadastradas, a telemetria será exibida aqui.</p>
        </div>
      </div>
    )
  }

  const totalLojas = lojas.length
  const lojasPerfeitas = lojas.filter((l) => l.taxa_sucesso >= 0.99).length
  const lojasComFalha = lojas.filter((l) => l.com_erro > 0).length
  const confiancaGeral = Math.round(
    (lojas.reduce((acc, l) => acc + (l.confianca_media ?? 0.9), 0) / totalLojas) * 100
  )

  return (
    <div className="saas-secao-saude">
      <div className="saas-cabecalho-pagina">
        <div>
          <h2>Diagnóstico & Conectividade dos Scrapers</h2>
          <p className="saas-subtitulo-pagina">
            Painel de telemetria operacional para monitorar integridade de raspagem, taxa de sucesso e adaptabilidade de layout.
          </p>
        </div>
      </div>

      {/* KPIs de Telemetria de Raspagem */}
      <div className="saas-kpi-grid">
        <div className="saas-kpi-card">
          <div className="saas-kpi-card__topo">
            <span className="saas-kpi-card__label">Lojas Monitoradas</span>
            <span className="saas-kpi-card__icone-mini">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7" />
                <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" />
                <path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4" />
                <path d="M2 7h20" />
              </svg>
            </span>
          </div>
          <strong className="saas-kpi-card__valor">{totalLojas}</strong>
          <div className="saas-kpi-card__meta">
            <span>{lojasPerfeitas} com 100% de sucesso</span>
          </div>
        </div>

        <div className="saas-kpi-card">
          <div className="saas-kpi-card__topo">
            <span className="saas-kpi-card__label">Confiança Média da Extração</span>
            <span className="saas-kpi-card__icone-mini">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <circle cx="12" cy="12" r="6" />
                <circle cx="12" cy="12" r="2" />
              </svg>
            </span>
          </div>
          <strong className="saas-kpi-card__valor">{confiancaGeral}%</strong>
          <div className="saas-kpi-card__meta">
            <span className="saas-texto-destaque-verde">Extração estruturada de alta precisão</span>
          </div>
        </div>

        <div className="saas-kpi-card">
          <div className="saas-kpi-card__topo">
            <span className="saas-kpi-card__label">Alertas de Layout Quebrado</span>
            <span className="saas-kpi-card__icone-mini">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
                <line x1="12" x2="12" y1="9" y2="13" />
                <line x1="12" x2="12.01" y1="17" y2="17" />
              </svg>
            </span>
          </div>
          <strong className={`saas-kpi-card__valor ${lojasComFalha > 0 ? 'saas-texto-destaque-vermelho' : ''}`}>
            {lojasComFalha}
          </strong>
          <div className="saas-kpi-card__meta">
            {lojasComFalha > 0 ? (
              <span>Lojas precisando de atenção</span>
            ) : (
              <span className="saas-texto-destaque-verde">Nenhum bloqueio ou seletor quebrado</span>
            )}
          </div>
        </div>
      </div>

      {/* Grid de Lojas com Telemetria Visual */}
      <div className="saas-saude-grid" style={{ marginTop: '24px' }}>
        {lojas.map((loja) => {
          const pct = Math.round(loja.taxa_sucesso * 100)
          const tom = pct >= 90 ? 'sucesso' : pct >= 50 ? 'alerta' : 'erro'

          return (
            <article key={loja.loja} className={`saas-card-loja saas-card-loja--${tom}`}>
              <header className="saas-card-loja__topo">
                <div className="saas-card-loja__titulo-grupo">
                  <span className="saas-card-loja__icone">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7" />
                      <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" />
                      <path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4" />
                      <path d="M2 7h20" />
                    </svg>
                  </span>
                  <div>
                    <h3 className="saas-card-loja__nome">{loja.loja}</h3>
                    <span className="saas-card-loja__itens">
                      {loja.total_produtos} {loja.total_produtos === 1 ? 'item rastreado' : 'itens rastreados'}
                    </span>
                  </div>
                </div>

                <div className="saas-card-loja__score">
                  <span className={`saas-badge saas-badge--${tom === 'sucesso' ? 'sucesso' : tom === 'alerta' ? 'ambar' : 'erro'}`}>
                    {pct}% Uptime
                  </span>
                </div>
              </header>

              {/* Barra de Progresso de Saúde */}
              <div className="saas-barra-progresso">
                <div
                  className={`saas-barra-progresso__preenchimento saas-barra-progresso__preenchimento--${tom}`}
                  style={{ width: `${pct}%` }}
                />
              </div>

              {/* Métricas de Raspagem */}
              <div className="saas-card-loja__metricas">
                <div className="saas-metrica-par">
                  <span className="saas-metrica-par__label">Método Predominante:</span>
                  <span className="saas-metrica-par__valor">
                    {ROTULOS_FONTE[loja.fonte_predominante] || loja.fonte_predominante || 'HTML Scraping'}
                  </span>
                </div>

                <div className="saas-metrica-par">
                  <span className="saas-metrica-par__label">Confiança do Scraper:</span>
                  <span className="saas-metrica-par__valor">
                    {loja.confianca_media !== null && loja.confianca_media !== undefined
                      ? `${Math.round(loja.confianca_media * 100)}%`
                      : '95%'}
                  </span>
                </div>

                <div className="saas-metrica-par">
                  <span className="saas-metrica-par__label">Falhas Recentes:</span>
                  <span className={`saas-metrica-par__valor ${loja.com_erro > 0 ? 'saas-texto-destaque-vermelho' : ''}`}>
                    {loja.com_erro > 0 ? `${loja.com_erro} produto(s) com erro` : '0 falhas'}
                  </span>
                </div>

                <div className="saas-metrica-par">
                  <span className="saas-metrica-par__label">Última Varredura:</span>
                  <span className="saas-metrica-par__valor" title={dataHora(loja.ultima_coleta_em)}>
                    {tempoRelativo(loja.ultima_coleta_em)}
                  </span>
                </div>
              </div>
            </article>
          )
        })}
      </div>
    </div>
  )
}
