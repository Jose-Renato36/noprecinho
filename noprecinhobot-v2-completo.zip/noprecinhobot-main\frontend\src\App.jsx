import { useCallback, useEffect, useRef, useState } from 'react'
import { api, sessao } from './api'
import Sidebar from './components/Sidebar'
import Topbar from './components/Topbar'
import DrawerAlertas from './components/DrawerAlertas'
import ModalCadastroProduto from './components/ModalCadastroProduto'
import ModalHistorico from './components/ModalHistorico'
import DashboardView from './components/DashboardView'
import TabelaProdutos from './components/TabelaProdutos'
import MatrizComparacao from './components/MatrizComparacao'
import SaudeLojas from './components/SaudeLojas'
import HistoricoEconomia from './components/HistoricoEconomia'
import ConfiguracoesNotificacoes from './components/ConfiguracoesNotificacoes'
import LojaDemo from './components/LojaDemo'
import PainelAlertas from './components/PainelAlertas'
import PerfilUsuario from './components/PerfilUsuario'
import TelaLogin from './components/TelaLogin'
import Toasts from './components/Toasts'

export default function App() {
  const [usuario, setUsuario] = useState(null)
  const [verificandoSessao, setVerificandoSessao] = useState(true)

  // Navegação e Layout SaaS
  const [aba, setAba] = useState('dashboard') // 'dashboard' | 'produtos' | 'matriz' | 'alertas' | 'saude' | 'economia' | 'demo' | 'configuracoes' | 'perfil'
  const [sidebarRecolhida, setSidebarRecolhida] = useState(false)
  const [sidebarMobileAberta, setSidebarMobileAberta] = useState(false)
  const [drawerAlertasAberto, setDrawerAlertasAberto] = useState(false)
  const [modalCadastroAberto, setModalCadastroAberto] = useState(false)
  const [filtroLojaGlobal, setFiltroLojaGlobal] = useState('')
  const [tema, setTema] = useState(() => {
    try {
      const salvo = localStorage.getItem('noprecinho_tema')
      if (salvo === 'dark' || salvo === 'light') return salvo
    } catch {
      /* fallback */
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
  })

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', tema)
    try {
      localStorage.setItem('noprecinho_tema', tema)
    } catch {
      /* fallback */
    }
  }, [tema])

  function alternarTema() {
    setTema((atual) => (atual === 'dark' ? 'light' : 'dark'))
  }

  // Dados
  const [produtos, setProdutos] = useState([])
  const [alertas, setAlertas] = useState([])
  const [resumo, setResumo] = useState(null)
  const [lojas, setLojas] = useState([])
  const [carregando, setCarregando] = useState(true)
  const [coletando, setColetando] = useState(false)
  const [ocupados, setOcupados] = useState(() => new Set())
  const [historicoAberto, setHistoricoAberto] = useState(null)
  const [falhaConexao, setFalhaConexao] = useState(null)
  const [avisos, setAvisos] = useState([])

  const proximoAviso = useRef(0)

  const avisar = useCallback((tipo, texto) => {
    const id = ++proximoAviso.current
    setAvisos((atuais) => [...atuais, { id, tipo, texto }])
    setTimeout(() => setAvisos((atuais) => atuais.filter((a) => a.id !== id)), 5000)
  }, [])

  const fecharAviso = useCallback(
    (id) => setAvisos((atuais) => atuais.filter((a) => a.id !== id)),
    []
  )

  const carregar = useCallback(async () => {
    try {
      const [listaProdutos, listaAlertas, dadosResumo, saude] = await Promise.all([
        api.listarProdutos(),
        api.listarAlertas(),
        api.resumo(),
        api.saudeLojas(),
      ])
      setProdutos(listaProdutos)
      setAlertas(listaAlertas)
      setResumo(dadosResumo)
      setLojas(saude)
      setFalhaConexao(null)
    } catch (e) {
      setFalhaConexao(e.message)
    } finally {
      setCarregando(false)
    }
  }, [])

  const sair = useCallback(async () => {
    try {
      await api.sair()
    } catch {
      /* ignorado de propósito */
    }
    setUsuario(null)
    setProdutos([])
    setAlertas([])
    setResumo(null)
    setLojas([])
    setAba('dashboard')
  }, [])

  const trocarConta = useCallback(async () => {
    try {
      await api.sair()
    } catch {
      /* ignorado */
    }
    setUsuario(null)
    setProdutos([])
    setAlertas([])
    setResumo(null)
    setLojas([])
    setAba('dashboard')
    avisar('info', 'Pronto! Digite os dados da outra conta para entrar.')
  }, [avisar])

  useEffect(() => {
    sessao.aoExpirar(() => {
      setUsuario(null)
      avisar('info', 'Sua sessão expirou. Entre novamente.')
    })
  }, [avisar])

  useEffect(() => {
    api
      .eu()
      .then(setUsuario)
      .catch(() => setUsuario(null))
      .finally(() => setVerificandoSessao(false))
  }, [])

  useEffect(() => {
    if (usuario) carregar()
  }, [usuario, carregar])

  useEffect(() => {
    if (!usuario) return
    const id = setInterval(carregar, 15000)
    return () => clearInterval(id)
  }, [usuario, carregar])

  function marcarOcupado(id, ocupado) {
    setOcupados((atuais) => {
      const copia = new Set(atuais)
      ocupado ? copia.add(id) : copia.delete(id)
      return copia
    })
  }

  async function comOcupado(produto, fn) {
    marcarOcupado(produto.id, true)
    try {
      await fn()
      await carregar()
    } catch (e) {
      avisar('erro', e.message)
    } finally {
      marcarOcupado(produto.id, false)
    }
  }

  const acoes = {
    pausar: (p) =>
      comOcupado(p, async () => {
        await api.pausarProduto(p.id)
        avisar('info', `Monitoramento de "${p.nome}" pausado.`)
      }),
    retomar: (p) =>
      comOcupado(p, async () => {
        await api.retomarProduto(p.id)
        avisar('sucesso', `Monitoramento de "${p.nome}" retomado.`)
      }),
    remover: (p) => {
      if (!window.confirm(`Deseja remover "${p.nome}"? O histórico será apagado.`)) return
      return comOcupado(p, async () => {
        await api.removerProduto(p.id)
        avisar('info', 'Produto removido com sucesso.')
      })
    },
    coletar: (p) =>
      comOcupado(p, async () => {
        const resultado = await api.coletarProduto(p.id)
        if (!resultado.sucesso) {
          return avisar('erro', resultado.erro ?? 'Não foi possível ler o preço nesta loja agora.')
        }
        avisar(
          resultado.alerta_gerado ? 'sucesso' : 'info',
          resultado.alerta_gerado
            ? `🎯 Alvo atingido! "${p.nome}" está por R$ ${resultado.preco.toFixed(2)}.`
            : `Preço verificado: R$ ${resultado.preco.toFixed(2)}.`
        )
      }),
    salvarAlvo: async (id, valor) => {
      try {
        await api.atualizarProduto(id, { preco_alvo: valor })
        await carregar()
        avisar('sucesso', 'Meta de preço atualizada com sucesso.')
      } catch (e) {
        avisar('erro', e.message)
      }
    },
  }

  async function coletarTudo() {
    setColetando(true)
    try {
      const rodada = await api.executarRodada()
      await carregar()
      if (rodada.alertas_gerados > 0) {
        avisar('sucesso', `🎯 ${rodada.alertas_gerados} produto(s) atingiram seu preço-alvo!`)
      } else {
        avisar('info', `Varredura concluída: ${rodada.sucessos} produto(s) atualizados.`)
      }
    } catch (e) {
      avisar('erro', e.message)
    } finally {
      setColetando(false)
    }
  }

  const naoLidos = alertas.filter((a) => !a.lido).length

  if (verificandoSessao) {
    return (
      <div className="saas-splash-screen">
        <div className="saas-splash-logo">🏷️</div>
        <span className="saas-spinner" />
        <p>Iniciando Price Intelligence Engine…</p>
      </div>
    )
  }

  if (!usuario) {
    return <TelaLogin aoEntrar={setUsuario} />
  }

  return (
    <div className={`saas-layout ${sidebarRecolhida ? 'saas-layout--sidebar-recolhida' : ''}`}>
      {/* Backdrop Mobile para Sidebar */}
      {sidebarMobileAberta && (
        <div
          className="saas-sidebar-overlay"
          onClick={() => setSidebarMobileAberta(false)}
          aria-hidden
        />
      )}

      {/* Barra Lateral (Sidebar) */}
      <div className={`saas-sidebar-wrapper ${sidebarMobileAberta ? 'saas-sidebar-wrapper--aberta' : ''}`}>
        <Sidebar
          abaAtiva={aba}
          aoMudarAba={(novaAba) => {
            setAba(novaAba)
            setSidebarMobileAberta(false)
          }}
          recolhido={sidebarRecolhida}
          aoAlternarRecolhido={() => setSidebarRecolhida((v) => !v)}
          naoLidos={naoLidos}
          aoAbrirNovoProduto={() => setModalCadastroAberto(true)}
        />
      </div>

      {/* Conteúdo Principal + Topbar */}
      <div className="saas-principal-wrapper">
        <Topbar
          usuario={usuario}
          aoSair={sair}
          falhaConexao={falhaConexao}
          naoLidos={naoLidos}
          aoAlternarAlertas={() => setDrawerAlertasAberto((v) => !v)}
          aoAbrirNovoProduto={() => setModalCadastroAberto(true)}
          aoColetarTudo={coletarTudo}
          coletando={coletando}
          aoAlternarSidebarMobile={() => setSidebarMobileAberta((v) => !v)}
          filtroLoja={filtroLojaGlobal}
          aoMudarFiltroLoja={setFiltroLojaGlobal}
          lojasDisponiveis={lojas}
          aoAbrirPerfil={() => setAba('perfil')}
          aoAbrirConfiguracoes={() => setAba('configuracoes')}
          aoTrocarConta={trocarConta}
          tema={tema}
          aoAlternarTema={alternarTema}
        />

        <main className="saas-conteudo">
          {falhaConexao && (
            <div className="saas-banner-erro" role="alert">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <line x1="12" x2="12" y1="8" y2="12" />
                <line x1="12" x2="12.01" y1="16" y2="16" />
              </svg>
              <div>
                <strong>Falha na comunicação com o backend:</strong> {falhaConexao}
              </div>
            </div>
          )}

          {aba === 'dashboard' && (
            <DashboardView
              resumo={resumo}
              produtos={produtos}
              alertas={alertas}
              lojas={lojas}
              ocupados={ocupados}
              acoes={acoes}
              aoAbrirHistorico={setHistoricoAberto}
              aoAbrirNovoProduto={() => setModalCadastroAberto(true)}
              aoMudarAba={setAba}
              filtroLoja={filtroLojaGlobal}
              aoColetarTudo={coletarTudo}
              coletando={coletando}
            />
          )}

          {aba === 'produtos' && (
            <div className="saas-pagina">
              <div className="saas-cabecalho-pagina">
                <div>
                  <h2>Monitor de Produtos & Histórico</h2>
                  <p className="saas-subtitulo-pagina">
                    Gerencie todos os itens rastreados, acompanhe gráficos de oscilação e ajuste metas de compra.
                  </p>
                </div>
                <button
                  className="saas-botao saas-botao--primario"
                  onClick={() => setModalCadastroAberto(true)}
                >
                  + Rastrear Produto
                </button>
              </div>

              <TabelaProdutos
                produtos={produtos}
                ocupados={ocupados}
                acoes={acoes}
                aoAbrirHistorico={setHistoricoAberto}
                aoAbrirNovoProduto={() => setModalCadastroAberto(true)}
                filtroLoja={filtroLojaGlobal}
              />
            </div>
          )}

          {aba === 'matriz' && (
            <MatrizComparacao
              produtos={produtos}
              aoAbrirNovoProduto={() => setModalCadastroAberto(true)}
            />
          )}

          {aba === 'alertas' && (
            <PainelAlertas
              alertas={alertas}
              emailAtivo={resumo?.email_ativo ?? false}
              aoMarcarLido={async (id) => {
                await api.marcarAlertaLido(id)
                carregar()
              }}
              aoMarcarTodos={async () => {
                await api.marcarTodosLidos()
                carregar()
              }}
              aoRemover={async (id) => {
                await api.removerAlerta(id)
                carregar()
              }}
            />
          )}

          {aba === 'saude' && <SaudeLojas lojas={lojas} resumo={resumo} />}

          {aba === 'economia' && (
            <HistoricoEconomia produtos={produtos} avisar={avisar} />
          )}

          {aba === 'demo' && <LojaDemo avisar={avisar} aoMudar={carregar} />}

          {aba === 'configuracoes' && (
            <ConfiguracoesNotificacoes avisar={avisar} resumo={resumo} />
          )}

          {aba === 'perfil' && (
            <PerfilUsuario
              usuario={usuario}
              produtos={produtos}
              alertas={alertas}
              resumo={resumo}
              aoSair={sair}
              aoTrocarConta={trocarConta}
              avisar={avisar}
            />
          )}
        </main>
      </div>

      {/* Drawer de Alertas Lateral */}
      <DrawerAlertas
        aberto={drawerAlertasAberto}
        aoFechar={() => setDrawerAlertasAberto(false)}
        alertas={alertas}
        emailAtivo={resumo?.email_ativo ?? false}
        aoMarcarLido={async (id) => {
          await api.marcarAlertaLido(id)
          carregar()
        }}
        aoMarcarTodos={async () => {
          await api.marcarTodosLidos()
          carregar()
        }}
        aoRemover={async (id) => {
          await api.removerAlerta(id)
          carregar()
        }}
      />

      {/* Modal / Drawer de Cadastro de Novo Produto */}
      <ModalCadastroProduto
        aberto={modalCadastroAberto}
        aoFechar={() => setModalCadastroAberto(false)}
        aoCadastrar={carregar}
        avisar={avisar}
      />

      {/* Modal de Histórico de Preços Detalhado */}
      {historicoAberto && (
        <ModalHistorico
          produto={historicoAberto}
          aoFechar={() => setHistoricoAberto(null)}
        />
      )}

      {/* Sistema de Toasts Flutuantes */}
      <Toasts avisos={avisos} aoFechar={fecharAviso} />
    </div>
  )
}
