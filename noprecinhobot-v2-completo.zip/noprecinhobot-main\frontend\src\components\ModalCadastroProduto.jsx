import { useRef, useState, useEffect } from 'react'
import { api } from '../api'
import { brl, ROTULOS_FONTE } from '../utils'

export default function ModalCadastroProduto({
  aberto,
  aoFechar,
  aoCadastrar,
  avisar,
}) {
  const [url, setUrl] = useState('')
  const [precoAlvo, setPrecoAlvo] = useState('')
  const [previa, setPrevia] = useState(null)
  const [buscando, setBuscando] = useState(false)
  const [salvando, setSalvando] = useState(false)
  const [erro, setErro] = useState(null)
  const [descontoAtivo, setDescontoAtivo] = useState(10)

  const buscaAtual = useRef(0)
  const inputUrlRef = useRef(null)

  useEffect(() => {
    if (aberto) {
      setTimeout(() => inputUrlRef.current?.focus(), 50)
    } else {
      limpar()
    }
  }, [aberto])

  function limpar() {
    setUrl('')
    setPrecoAlvo('')
    setPrevia(null)
    setErro(null)
    setBuscando(false)
    setSalvando(false)
    setDescontoAtivo(10)
  }

  async function buscarProduto(endereco) {
    const limpo = endereco.trim()
    if (!/^https?:\/\/\S+\.\S+/i.test(limpo)) return

    const minhaBusca = ++buscaAtual.current
    setBuscando(true)
    setErro(null)
    setPrevia(null)

    try {
      const resultado = await api.previa(limpo)
      if (minhaBusca !== buscaAtual.current) return
      setPrevia(resultado)
      if (resultado.preco) {
        aplicarDesconto(resultado.preco, 10)
      }
    } catch (e) {
      if (minhaBusca === buscaAtual.current) setErro(e.message)
    } finally {
      if (minhaBusca === buscaAtual.current) setBuscando(false)
    }
  }

  function aplicarDesconto(precoBase, percentual) {
    setDescontoAtivo(percentual)
    if (!precoBase) return
    const valorCalculado = Number(precoBase) * (1 - percentual / 100)
    setPrecoAlvo(valorCalculado.toFixed(2))
  }

  async function enviar(evento) {
    evento.preventDefault()
    setErro(null)

    const alvo = Number(String(precoAlvo).replace(',', '.'))
    if (!url.trim()) return setErro('Cole a URL completa do produto.')
    if (!Number.isFinite(alvo) || alvo <= 0) return setErro('Defina uma meta de preço válida maior que zero.')

    setSalvando(true)
    try {
      const produto = await api.cadastrarProduto(url.trim(), Number(alvo.toFixed(2)))
      avisar('sucesso', `Monitorando "${produto.nome}" com sucesso!`)
      aoCadastrar()
      aoFechar()
      limpar()
    } catch (e) {
      setErro(e.message)
    } finally {
      setSalvando(false)
    }
  }

  if (!aberto) return null

  return (
    <div className="saas-modal-backdrop" onClick={aoFechar}>
      <div
        className="saas-modal saas-modal--medio"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-cadastro-titulo"
      >
        <div className="saas-modal__cabecalho">
          <div className="saas-modal__titulo-grupo">
            <div className="saas-modal__icone-destaque">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5 12h14" />
                <path d="M12 5v14" />
              </svg>
            </div>
            <div>
              <h3 id="modal-cadastro-titulo">Rastrear Novo Produto</h3>
              <span className="saas-modal__subtitulo">
                Cole a URL de qualquer loja para iniciar a vigilância contínua
              </span>
            </div>
          </div>
          <button className="saas-modal__fechar" onClick={aoFechar} aria-label="Fechar">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M18 6 6 18" />
              <path d="m6 6 12 12" />
            </svg>
          </button>
        </div>

        <form onSubmit={enviar} className="saas-modal__form">
          <div className="saas-campo">
            <label htmlFor="input-cadastro-url" className="saas-campo__label">
              URL do Produto (Qualquer E-commerce)
            </label>
            <div className="saas-campo__input-grupo">
              <span className="saas-campo__prefixo-icone">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                  <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
                </svg>
              </span>
              <input
                id="input-cadastro-url"
                ref={inputUrlRef}
                type="url"
                inputMode="url"
                className="saas-campo__input"
                placeholder="Ex: https://www.kabum.com.br/produto/12345 ou https://amazon.com.br/dp/..."
                value={url}
                onChange={(e) => {
                  setUrl(e.target.value)
                  setPrevia(null)
                }}
                onPaste={(e) => {
                  const colado = e.clipboardData.getData('text')
                  setTimeout(() => buscarProduto(colado), 0)
                }}
                onBlur={(e) => !previa && buscarProduto(e.target.value)}
                disabled={salvando}
              />
            </div>
            <span className="saas-campo__dica">
              Ao colar, o scraper varre a página instantaneamente e extrai preço, imagem e loja.
            </span>
          </div>

          {/* Skeleton de Carregamento */}
          {buscando && (
            <div className="saas-skeleton-box">
              <div className="saas-skeleton saas-skeleton--thumb" />
              <div className="saas-skeleton__linhas">
                <div className="saas-skeleton saas-skeleton--linha saas-skeleton--linha-longa" />
                <div className="saas-skeleton saas-skeleton--linha saas-skeleton--linha-media" />
                <div className="saas-skeleton saas-skeleton--linha saas-skeleton--linha-curta" />
              </div>
            </div>
          )}

          {/* Card de Pré-visualização Enriquecido */}
          {previa && (
            <div className="saas-previa-card">
              <div className="saas-previa-card__imagem-box">
                {previa.imagem_url ? (
                  <img src={previa.imagem_url} alt="" className="saas-previa-card__imagem" />
                ) : (
                  <div className="saas-previa-card__sem-imagem">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
                      <path d="m7.5 4.27 9 5.15" />
                      <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
                    </svg>
                  </div>
                )}
              </div>

              <div className="saas-previa-card__info">
                <div className="saas-previa-card__tags">
                  <span className="saas-badge saas-badge--azul">{previa.loja || 'E-commerce'}</span>
                  {previa.fonte && (
                    <span className="saas-badge saas-badge--neutro" title="Método de raspagem">
                      via {ROTULOS_FONTE[previa.fonte] || previa.fonte}
                    </span>
                  )}
                  {previa.confianca > 0 && (
                    <span className="saas-badge saas-badge--sucesso">
                      {Math.round(previa.confianca * 100)}% precisão
                    </span>
                  )}
                </div>

                <strong className="saas-previa-card__titulo">{previa.nome}</strong>

                <div className="saas-previa-card__preco-atual">
                  <span>Preço Atual Detectado:</span>
                  <strong>{brl(previa.preco)}</strong>
                </div>
              </div>
            </div>
          )}

          {/* Definição de Meta de Preço e Gatilho de Alerta */}
          {previa && (
            <div className="saas-secao-meta">
              <label htmlFor="input-preco-alvo" className="saas-campo__label">
                Preço Alvo Desejado para Alerta
              </label>

              <div className="saas-campo__moeda-wrapper">
                <span className="saas-campo__moeda-simbolo">R$</span>
                <input
                  id="input-preco-alvo"
                  type="number"
                  step="0.01"
                  min="0.01"
                  className="saas-campo__input saas-campo__input--destaque"
                  placeholder="0,00"
                  value={precoAlvo}
                  onChange={(e) => {
                    setPrecoAlvo(e.target.value)
                    setDescontoAtivo(null)
                  }}
                  disabled={salvando}
                  required
                />
              </div>

              {/* Botões de atalho de desconto rápido */}
              {previa.preco && (
                <div className="saas-descontos-atalho">
                  <span className="saas-descontos-atalho__label">Atalhos rápidos:</span>
                  {[5, 10, 15, 20, 30].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      className={`saas-chip ${descontoAtivo === pct ? 'saas-chip--ativo' : ''}`}
                      onClick={() => aplicarDesconto(previa.preco, pct)}
                    >
                      -{pct}% ({brl(Number(previa.preco) * (1 - pct / 100))})
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {erro && (
            <div className="saas-alerta-erro">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <line x1="12" x2="12" y1="8" y2="12" />
                <line x1="12" x2="12.01" y1="16" y2="16" />
              </svg>
              <span>{erro}</span>
            </div>
          )}

          <div className="saas-modal__acoes">
            <button
              type="button"
              className="saas-botao saas-botao--secundario"
              onClick={aoFechar}
              disabled={salvando}
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="saas-botao saas-botao--primario"
              disabled={salvando || buscando || !previa}
            >
              {salvando ? (
                <>
                  <span className="saas-spinner saas-spinner--mini" />
                  Salvando…
                </>
              ) : (
                'Iniciar Monitoramento'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
