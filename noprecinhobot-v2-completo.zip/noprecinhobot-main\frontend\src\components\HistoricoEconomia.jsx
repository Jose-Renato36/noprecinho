import { useState, useMemo } from 'react'
import { brl, tempoRelativo, dataHora } from '../utils'

const CHAVE_STORAGE_COMPRADOS = 'noprecinho_itens_comprados'

export default function HistoricoEconomia({ produtos = [], avisar }) {
  const [comprados, setComprados] = useState(() => {
    try {
      const salvo = localStorage.getItem(CHAVE_STORAGE_COMPRADOS)
      if (salvo) return JSON.parse(salvo)
    } catch {
      /* fallback */
    }
    return []
  })

  // Produtos que atingiram o alvo e podem ser marcados como comprados
  const produtosNoPreco = useMemo(() => {
    return produtos.filter(
      (p) => p.status === 'alvo_atingido' && !comprados.some((c) => c.id === p.id)
    )
  }, [produtos, comprados])

  // Métricas Consolidadas de Economia
  const metricas = useMemo(() => {
    let totalEconomizado = 0
    let totalInvestido = 0

    comprados.forEach((item) => {
      const inicial = Number(item.preco_inicial || item.preco_atual)
      const pago = Number(item.preco_pago || item.preco_atual)
      if (inicial > pago) {
        totalEconomizado += inicial - pago
      }
      totalInvestido += pago
    })

    const economiaPotencialAtual = produtos.reduce((acc, p) => {
      const inicial = Number(p.preco_inicial || p.preco_atual || 0)
      const atual = Number(p.preco_atual || 0)
      return inicial > atual ? acc + (inicial - atual) : acc
    }, 0)

    const pctEconomia =
      totalInvestido + totalEconomizado > 0
        ? Math.round((totalEconomizado / (totalInvestido + totalEconomizado)) * 100)
        : 0

    return {
      totalEconomizado,
      totalInvestido,
      economiaPotencialAtual,
      pctEconomia,
      totalItens: comprados.length,
    }
  }, [comprados, produtos])

  function marcarComoComprado(p) {
    const novoItem = {
      id: p.id,
      nome: p.nome,
      loja: p.loja,
      url: p.url,
      imagem_url: p.imagem_url,
      preco_inicial: p.preco_inicial || p.preco_atual,
      preco_pago: p.preco_atual,
      preco_alvo: p.preco_alvo,
      data_compra: new Date().toISOString(),
    }

    const novaLista = [novoItem, ...comprados]
    setComprados(novaLista)
    localStorage.setItem(CHAVE_STORAGE_COMPRADOS, JSON.stringify(novaLista))
    avisar('sucesso', `"${p.nome}" movido para seu histórico de compras economizadas!`)
  }

  function removerComprado(id) {
    const novaLista = comprados.filter((c) => c.id !== id)
    setComprados(novaLista)
    localStorage.setItem(CHAVE_STORAGE_COMPRADOS, JSON.stringify(novaLista))
    avisar('info', 'Item removido do histórico de economia.')
  }

  return (
    <div className="saas-secao-economia">
      <div className="saas-cabecalho-pagina">
        <div>
          <h2>Histórico de Economia & Wishlist Concluída</h2>
          <p className="saas-subtitulo-pagina">
            Acompanhe o retorno financeiro real do seu monitoramento contínuo de preços.
          </p>
        </div>
      </div>

      {/* KPI Cards de ROI & Economia */}
      <div className="saas-kpi-grid">
        <div className="saas-kpi-card saas-kpi-card--verde">
          <div className="saas-kpi-card__icone">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="12" x2="12" y1="2" y2="22" />
              <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
            </svg>
          </div>
          <div className="saas-kpi-card__conteudo">
            <span className="saas-kpi-card__label">Total Economizado (Compras)</span>
            <strong className="saas-kpi-card__valor">{brl(metricas.totalEconomizado)}</strong>
            <span className="saas-kpi-card__meta">
              Economia média de <strong>{metricas.pctEconomia}%</strong> por item
            </span>
          </div>
        </div>

        <div className="saas-kpi-card">
          <div className="saas-kpi-card__icone">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" />
              <polyline points="16 7 22 7 22 13" />
            </svg>
          </div>
          <div className="saas-kpi-card__conteudo">
            <span className="saas-kpi-card__label">Economia Potencial Ativa</span>
            <strong className="saas-kpi-card__valor">{brl(metricas.economiaPotencialAtual)}</strong>
            <span className="saas-kpi-card__meta">Quedas acumuladas na sua lista ativa</span>
          </div>
        </div>

        <div className="saas-kpi-card">
          <div className="saas-kpi-card__icone">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z" />
              <path d="M3 6h18" />
              <path d="M16 10a4 4 0 0 1-8 0" />
            </svg>
          </div>
          <div className="saas-kpi-card__conteudo">
            <span className="saas-kpi-card__label">Itens Concluídos</span>
            <strong className="saas-kpi-card__valor">{metricas.totalItens} produtos</strong>
            <span className="saas-kpi-card__meta">Aproveitados no melhor preço</span>
          </div>
        </div>
      </div>

      {/* Oportunidades Prontas para Concluir */}
      {produtosNoPreco.length > 0 && (
        <section className="saas-card saas-card--destaque-borda" style={{ marginTop: '24px' }}>
          <header className="saas-card__cabecalho">
            <div>
              <h3>Prontos para Compra (Alvo Atingido)</h3>
              <p>Estes itens atingiram sua meta de preço. Se você já comprou, registre para somar à economia.</p>
            </div>
          </header>

          <div className="saas-oportunidades-lista">
            {produtosNoPreco.map((p) => {
              const economia = Number(p.preco_inicial || p.preco_atual) - Number(p.preco_atual)
              return (
                <div key={p.id} className="saas-oportunidade-item">
                  <div className="saas-oportunidade-item__info">
                    {p.imagem_url ? (
                      <img src={p.imagem_url} alt="" className="saas-oportunidade-item__thumb" />
                    ) : (
                      <div className="saas-oportunidade-item__thumb-vazio">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="m7.5 4.27 9 5.15" />
                          <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
                        </svg>
                      </div>
                    )}
                    <div>
                      <strong>{p.nome}</strong>
                      <div className="saas-oportunidade-item__precos">
                        <span className="saas-oportunidade-item__preco-atual">
                          Preço agora: <strong>{brl(p.preco_atual)}</strong>
                        </span>
                        {p.preco_inicial && (
                          <span className="saas-oportunidade-item__preco-original">
                            (Era {brl(p.preco_inicial)})
                          </span>
                        )}
                        {economia > 0 && (
                          <span className="saas-badge saas-badge--sucesso">
                            Economia de {brl(economia)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="saas-oportunidade-item__acoes">
                    <a
                      href={p.url}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="saas-botao saas-botao--primario saas-botao--mini"
                    >
                      <span>Comprar na Loja</span>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginLeft: '4px' }}>
                        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                        <polyline points="15 3 21 3 21 9" />
                        <line x1="10" y1="14" x2="21" y2="3" />
                      </svg>
                    </a>
                    <button
                      className="saas-botao saas-botao--suave saas-botao--mini"
                      onClick={() => marcarComoComprado(p)}
                    >
                      Marcar como Comprado
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        </section>
      )}

      {/* Histórico de Compras Concluídas */}
      <section className="saas-card" style={{ marginTop: '24px' }}>
        <header className="saas-card__cabecalho">
          <h3>Wishlist Realizada & Histórico de Sucesso</h3>
        </header>

        {comprados.length === 0 ? (
          <div className="saas-vazio saas-vazio--compacto">
            <p>Nenhum item marcado como comprado ainda. Registre suas compras aproveitadas acima para calcular seu ROI.</p>
          </div>
        ) : (
          <div className="saas-tabela-container">
            <table className="saas-tabela">
              <thead>
                <tr>
                  <th>Produto Comprado</th>
                  <th>Loja</th>
                  <th>Preço Original</th>
                  <th>Preço Pago</th>
                  <th>Economia Obtida</th>
                  <th>Data</th>
                  <th style={{ textAlign: 'right' }}>Ação</th>
                </tr>
              </thead>
              <tbody>
                {comprados.map((item) => {
                  const economia = Number(item.preco_inicial) - Number(item.preco_pago)
                  const pct =
                    item.preco_inicial > 0
                      ? Math.round((economia / Number(item.preco_inicial)) * 100)
                      : 0

                  return (
                    <tr key={item.id}>
                      <td>
                        <div className="saas-celula-produto">
                          {item.imagem_url && (
                            <img src={item.imagem_url} alt="" className="saas-celula-produto__thumb" />
                          )}
                          <a
                            href={item.url}
                            target="_blank"
                            rel="noreferrer noopener"
                            className="saas-celula-produto__nome"
                          >
                            {item.nome}
                          </a>
                        </div>
                      </td>
                      <td>{item.loja || '—'}</td>
                      <td>{brl(item.preco_inicial)}</td>
                      <td>
                        <strong>{brl(item.preco_pago)}</strong>
                      </td>
                      <td>
                        <span className="saas-badge saas-badge--sucesso">
                          {brl(Math.max(0, economia))} ({pct}%)
                        </span>
                      </td>
                      <td>{dataHora(item.data_compra)}</td>
                      <td style={{ textAlign: 'right' }}>
                        <button
                          className="saas-botao saas-botao--icone-mini saas-botao--perigo-suave"
                          onClick={() => removerComprado(item.id)}
                          title="Remover do histórico"
                        >
                          ✕
                        </button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  )
}
