import { useState } from 'react'

export const ITENS_MENU = [
  {
    id: 'dashboard',
    rotulo: 'Dashboard',
    icone: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect width="7" height="9" x="3" y="3" rx="1" />
        <rect width="7" height="5" x="14" y="3" rx="1" />
        <rect width="7" height="9" x="14" y="12" rx="1" />
        <rect width="7" height="5" x="3" y="16" rx="1" />
      </svg>
    ),
  },
  {
    id: 'produtos',
    rotulo: 'Produtos & Monitor',
    icone: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="m7.5 4.27 9 5.15" />
        <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
        <path d="m3.3 7 8.7 5 8.7-5" />
        <path d="M12 22V12" />
      </svg>
    ),
  },
  {
    id: 'matriz',
    rotulo: 'Comparador de Lojas',
    icone: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
        <path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
        <path d="M7 21h10" />
        <path d="M12 3v18" />
        <path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2" />
      </svg>
    ),
  },
  {
    id: 'alertas',
    rotulo: 'Feed de Alertas',
    badge: 'alertas',
    icone: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
        <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
      </svg>
    ),
  },
  {
    id: 'saude',
    rotulo: 'Saúde dos Scrapers',
    icone: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.48 12H2" />
      </svg>
    ),
  },
  {
    id: 'economia',
    rotulo: 'Histórico de Economia',
    icone: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
      </svg>
    ),
  },
  {
    id: 'demo',
    rotulo: 'Loja Sandbox (Demo)',
    icone: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M10 2v7.31" />
        <path d="M14 9.3V1.99" />
        <path d="M8.5 2h7" />
        <path d="M14 9.3a6.5 6.5 0 1 1-4 0" />
        <path d="M5.52 16h12.96" />
      </svg>
    ),
  },
]

export default function Sidebar({
  abaAtiva,
  aoMudarAba,
  recolhido,
  aoAlternarRecolhido,
  naoLidos = 0,
  aoAbrirNovoProduto,
}) {
  return (
    <aside className={`saas-sidebar ${recolhido ? 'saas-sidebar--recolhida' : ''}`}>
      <div className="saas-sidebar__cabecalho">
        <div className="saas-sidebar__marca">
          <div className="saas-sidebar__logo-icone" aria-hidden>
            <span>🏷️</span>
          </div>
          {!recolhido && (
            <div className="saas-sidebar__marca-texto">
              <span className="saas-sidebar__titulo">NoPrecinho<strong>Bot</strong></span>
              <span className="saas-sidebar__subtitulo">Price Intelligence SaaS</span>
            </div>
          )}
        </div>
        <button
          className="saas-sidebar__toggle"
          onClick={aoAlternarRecolhido}
          title={recolhido ? 'Expandir barra lateral' : 'Recolher barra lateral'}
          aria-label={recolhido ? 'Expandir barra lateral' : 'Recolher barra lateral'}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ transform: recolhido ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s ease' }}>
            <path d="m15 18-6-6 6-6" />
          </svg>
        </button>
      </div>

      <div className="saas-sidebar__acao-rapida">
        <button
          className="saas-botao saas-botao--primario saas-botao--bloco"
          onClick={aoAbrirNovoProduto}
          title="Adicionar novo produto para monitorar"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M5 12h14" />
            <path d="M12 5v14" />
          </svg>
          {!recolhido && <span>Novo Produto</span>}
        </button>
      </div>

      <nav className="saas-sidebar__navegacao" aria-label="Menu Principal">
        <ul className="saas-sidebar__lista">
          {ITENS_MENU.map((item) => {
            const ativo = abaAtiva === item.id
            return (
              <li key={item.id}>
                <button
                  className={`saas-sidebar__link ${ativo ? 'saas-sidebar__link--ativo' : ''}`}
                  onClick={() => aoMudarAba(item.id)}
                  title={recolhido ? item.rotulo : undefined}
                >
                  <span className="saas-sidebar__link-icone">{item.icone}</span>
                  {!recolhido && <span className="saas-sidebar__link-rotulo">{item.rotulo}</span>}
                  {item.badge === 'alertas' && naoLidos > 0 && (
                    <span className="saas-sidebar__badge" title={`${naoLidos} alertas não lidos`}>
                      {naoLidos > 99 ? '99+' : naoLidos}
                    </span>
                  )}
                </button>
              </li>
            )
          })}
        </ul>
      </nav>

      <div className="saas-sidebar__rodape">
        {!recolhido && (
          <div className="saas-sidebar__info">
            <span className="saas-sidebar__versao">NoPrecinhoBot v2.4</span>
          </div>
        )}
      </div>
    </aside>
  )
}
