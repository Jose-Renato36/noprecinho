import { useState, useEffect } from 'react'

const CHAVE_STORAGE = 'noprecinho_config_notificacoes'

export default function ConfiguracoesNotificacoes({ avisar, resumo }) {
  const [config, setConfig] = useState(() => {
    try {
      const salvo = localStorage.getItem(CHAVE_STORAGE)
      if (salvo) return JSON.parse(salvo)
    } catch {
      /* fallback */
    }
    return {
      emailAtivo: true,
      emailDestino: '',
      telegramAtivo: false,
      telegramChatId: '',
      discordAtivo: false,
      discordWebhookUrl: '',
      pushAtivo: false,
      gatilhoMinimoDesconto: 5, // %
      notificarApenasNoAlvo: true,
      notificarErrosScraper: true,
      frequenciaResumo: 'diario', // 'imediato', 'diario', 'semanal'
    }
  })

  const [salvo, setSalvo] = useState(false)

  function atualizarCampo(campo, valor) {
    setConfig((anterior) => ({ ...anterior, [campo]: valor }))
    setSalvo(false)
  }

  function salvarConfiguracoes(e) {
    e.preventDefault()
    try {
      localStorage.setItem(CHAVE_STORAGE, JSON.stringify(config))
      setSalvo(true)
      avisar('sucesso', 'Preferências de notificação salvas com sucesso!')
      setTimeout(() => setSalvo(false), 3000)
    } catch (e) {
      avisar('erro', 'Não foi possível salvar as preferências no navegador.')
    }
  }

  async function solicitarPermissaoPush() {
    if (!('Notification' in window)) {
      return avisar('erro', 'Este navegador não suporta notificações Web Push.')
    }
    const permissao = await Notification.requestPermission()
    if (permissao === 'granted') {
      atualizarCampo('pushAtivo', true)
      avisar('sucesso', 'Notificações do navegador ativadas com sucesso!')
      new Notification('NoPrecinhoBot Ativo', {
        body: 'Você receberá alertas em tempo real direto na sua área de trabalho quando o preço baixar.',
        icon: '🏷️',
      })
    } else {
      atualizarCampo('pushAtivo', false)
      avisar('erro', 'Permissão de notificação negada no navegador.')
    }
  }

  return (
    <div className="saas-secao-config">
      <div className="saas-cabecalho-pagina">
        <div>
          <h2>Canais de Alerta & Regras de Notificação</h2>
          <p className="saas-subtitulo-pagina">
            Defina por onde deseja ser avisado quando um preço despencar e ajuste a sensibilidade dos disparos.
          </p>
        </div>
      </div>

      <form onSubmit={salvarConfiguracoes} className="saas-config-grid">
        {/* Canais de Comunicação */}
        <section className="saas-card-config">
          <header className="saas-card-config__topo">
            <div className="saas-card-config__icone">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4.9 19.1C1 15.2 1 8.8 4.9 4.9" />
                <path d="M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5" />
                <circle cx="12" cy="12" r="2" />
                <path d="M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5" />
                <path d="M19.1 4.9C23 8.8 23 15.1 19.1 19" />
              </svg>
            </div>
            <div>
              <h3>Canais de Envio de Alerta</h3>
              <p>Escolha uma ou mais plataformas para receber os avisos em tempo real.</p>
            </div>
          </header>

          <div className="saas-canais-lista">
            {/* Canal E-mail */}
            <div className="saas-canal-item">
              <div className="saas-canal-item__info">
                <div className="saas-canal-item__titulo-box">
                  <span className="saas-canal-icone">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect width="20" height="16" x="2" y="4" rx="2" />
                      <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
                    </svg>
                  </span>
                  <strong>Notificações por E-mail</strong>
                  {resumo?.email_ativo ? (
                    <span className="saas-badge saas-badge--sucesso">Servidor Resend Ativo</span>
                  ) : (
                    <span className="saas-badge saas-badge--neutro">Servidor em modo Local</span>
                  )}
                </div>
                <p>Receba relatórios e avisos quando o valor cair.</p>
              </div>
              <label className="saas-switch">
                <input
                  type="checkbox"
                  checked={config.emailAtivo}
                  onChange={(e) => atualizarCampo('emailAtivo', e.target.checked)}
                />
                <span className="saas-switch__slider" />
              </label>
            </div>

            {/* Canal Web Push (Navegador) */}
            <div className="saas-canal-item">
              <div className="saas-canal-item__info">
                <div className="saas-canal-item__titulo-box">
                  <span className="saas-canal-icone">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
                      <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
                    </svg>
                  </span>
                  <strong>Notificações Push Web</strong>
                  {config.pushAtivo && <span className="saas-badge saas-badge--sucesso">Ativo</span>}
                </div>
                <p>Exibe notificações nativas do sistema operacional (Windows/Mac/Linux).</p>
              </div>
              <button
                type="button"
                className={`saas-botao saas-botao--mini ${config.pushAtivo ? 'saas-botao--secundario' : 'saas-botao--primario'}`}
                onClick={solicitarPermissaoPush}
              >
                {config.pushAtivo ? 'Testar Push' : 'Ativar Push'}
              </button>
            </div>

            {/* Canal Telegram Bot */}
            <div className="saas-canal-item">
              <div className="saas-canal-item__info">
                <div className="saas-canal-item__titulo-box">
                  <span className="saas-canal-icone">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="m22 2-7 20-4-9-9-4Z" />
                      <path d="M22 2 11 13" />
                    </svg>
                  </span>
                  <strong>Bot do Telegram</strong>
                </div>
                <p>Receba alertas instantâneos no seu Telegram particular ou canal.</p>
                {config.telegramAtivo && (
                  <div className="saas-campo saas-campo--compacto" style={{ marginTop: '8px' }}>
                    <input
                      type="text"
                      className="saas-campo__input"
                      placeholder="Telegram Chat ID (Ex: 123456789)"
                      value={config.telegramChatId}
                      onChange={(e) => atualizarCampo('telegramChatId', e.target.value)}
                    />
                  </div>
                )}
              </div>
              <label className="saas-switch">
                <input
                  type="checkbox"
                  checked={config.telegramAtivo}
                  onChange={(e) => atualizarCampo('telegramAtivo', e.target.checked)}
                />
                <span className="saas-switch__slider" />
              </label>
            </div>

            {/* Canal Discord Webhook */}
            <div className="saas-canal-item">
              <div className="saas-canal-item__info">
                <div className="saas-canal-item__titulo-box">
                  <span className="saas-canal-icone">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect width="20" height="12" x="2" y="6" rx="2" />
                      <path d="M12 12h.01" />
                      <path d="M17 12h.01" />
                      <path d="M7 12h.01" />
                    </svg>
                  </span>
                  <strong>Discord Webhook</strong>
                </div>
                <p>Envie cards formatados para um canal do seu servidor no Discord.</p>
                {config.discordAtivo && (
                  <div className="saas-campo saas-campo--compacto" style={{ marginTop: '8px' }}>
                    <input
                      type="url"
                      className="saas-campo__input"
                      placeholder="https://discord.com/api/webhooks/..."
                      value={config.discordWebhookUrl}
                      onChange={(e) => atualizarCampo('discordWebhookUrl', e.target.value)}
                    />
                  </div>
                )}
              </div>
              <label className="saas-switch">
                <input
                  type="checkbox"
                  checked={config.discordAtivo}
                  onChange={(e) => atualizarCampo('discordAtivo', e.target.checked)}
                />
                <span className="saas-switch__slider" />
              </label>
            </div>
          </div>
        </section>

        {/* Sensibilidade e Regras de Disparo */}
        <section className="saas-card-config">
          <header className="saas-card-config__topo">
            <div className="saas-card-config__icone">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.48 12H2" />
              </svg>
            </div>
            <div>
              <h3>Sensibilidade dos Gatilhos</h3>
              <p>Evite ruído ajustando as condições exatas para o disparo de alertas.</p>
            </div>
          </header>

          <div className="saas-regras-lista">
            <div className="saas-campo">
              <label className="saas-campo__label">
                Queda Mínima de Preço para Disparo (%):
              </label>
              <div className="saas-campo__range-wrapper">
                <input
                  type="range"
                  min="1"
                  max="50"
                  step="1"
                  value={config.gatilhoMinimoDesconto}
                  onChange={(e) => atualizarCampo('gatilhoMinimoDesconto', Number(e.target.value))}
                  className="saas-range-input"
                />
                <span className="saas-range-valor">
                  Pelo menos <strong>{config.gatilhoMinimoDesconto}%</strong> de queda
                </span>
              </div>
              <span className="saas-campo__dica">
                Ignora oscilações diárias insignificantes de centavos.
              </span>
            </div>

            <div className="saas-divisor" />

            <div className="saas-check-linha">
              <input
                id="check-alvo-atingido"
                type="checkbox"
                checked={config.notificarApenasNoAlvo}
                onChange={(e) => atualizarCampo('notificarApenasNoAlvo', e.target.checked)}
              />
              <label htmlFor="check-alvo-atingido">
                <strong>Avisar imediatamente quando o preço atingir ou ultrapassar o alvo</strong>
                <p>Prioridade máxima — dispara alerta instantâneo assim que o scraper detectar.</p>
              </label>
            </div>

            <div className="saas-check-linha">
              <input
                id="check-erros"
                type="checkbox"
                checked={config.notificarErrosScraper}
                onChange={(e) => atualizarCampo('notificarErrosScraper', e.target.checked)}
              />
              <label htmlFor="check-erros">
                <strong>Notificar sobre falhas repetidas de coleta na loja</strong>
                <p>Receba aviso se uma loja mudar o layout ou bloquear o robô.</p>
              </label>
            </div>
          </div>

          <div className="saas-card-config__rodape">
            <button type="submit" className="saas-botao saas-botao--primario">
              {salvo ? 'Preferências Salvas' : 'Salvar Configurações'}
            </button>
          </div>
        </section>
      </form>
    </div>
  )
}
