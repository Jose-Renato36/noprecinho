import { useState, useMemo } from 'react'
import { brl, tempoRelativo, dataHora, ROTULOS_FONTE } from '../utils'
import GraficoHistorico from './GraficoHistorico'
import CardProduto from './CardProduto'

export default function TabelaProdutos({
  produtos = [],
  ocupados = new Set(),
  acoes,
  aoAbrirHistorico,
  aoAbrirNovoProduto,
  filtroLoja,
}) {
  const [modoVisualizacao, setModoVisualizacao] = useState('tabela') // 'tabela' | 'grid'
  const [busca, setBusca] = useState('')
  const [filtroStatus, setFiltroStatus] = useState('')
  const [ordenacao, setOrdenacao] = useState('variacao_desc') // 'variacao_desc', 'preco_asc', 'preco_desc', 'nome_asc', 'recente'
  const [linhasExpandidas, setLinhasExpandidas] = useState(() => new Set())
  const [pagina, setPagina] = useState(1)
  const [itensPorPagina, setItensPorPagina] = useState(15)
  const [editandoAlvoId, setEditandoAlvoId] = useState(null)
  const [novoAlvoValor, setNovoAlvoValor] = useState('')

  // Toggle de expansão de linha
  function alternarExpansao(id) {
    setLinhasExpandidas((atuais) => {
      const copia = new Set(atuais)
      copia.has(id) ? copia.delete(id) : copia.add(id)
      return copia
    })
  }

  // Filtragem
  const produtosFiltrados = useMemo(() => {
    return produtos.filter((p) => {
      if (filtroLoja && p.loja !== filtroLoja) return false
      if (filtroStatus && p.status !== filtroStatus) return false
      if (busca) {
        const termo = busca.toLowerCase()
        const nomeMatch = p.nome?.toLowerCase().includes(termo)
        const lojaMatch = p.loja?.toLowerCase().includes(termo)
        if (!nomeMatch && !lojaMatch) return false
      }
      return true
    })
  }, [produtos, filtroLoja, filtroStatus, busca])

  // Ordenação
  const produtosOrdenados = useMemo(() => {
    const lista = [...produtosFiltrados]
    lista.sort((a, b) => {
      switch (ordenacao) {
        case 'variacao_desc':
          return (a.variacao_percentual ?? 0) - (b.variacao_percentual ?? 0) // Menor variação primeiro (maior queda)
        case 'variacao_asc':
          return (b.variacao_percentual ?? 0) - (a.variacao_percentual ?? 0)
        case 'preco_asc':
          return Number(a.preco_atual ?? Infinity) - Number(b.preco_atual ?? Infinity)
        case 'preco_desc':
          return Number(b.preco_atual ?? 0) - Number(a.preco_atual ?? 0)
        case 'nome_asc':
          return (a.nome || '').localeCompare(b.nome || '')
        case 'recente':
        default:
          return new Date(b.ultima_coleta_em || 0) - new Date(a.ultima_coleta_em || 0)
      }
    })
    return lista
  }, [produtosFiltrados, ordenacao])

  // Paginação
  const totalPaginas = Math.ceil(produtosOrdenados.length / itensPorPagina) || 1
  const paginaAjustada = Math.min(pagina, totalPaginas)
  const inicio = (paginaAjustada - 1) * itensPorPagina
  const produtosPaginados = produtosOrdenados.slice(inicio, inicio + itensPorPagina)

  function iniciarEdicaoAlvo(p) {
    setEditandoAlvoId(p.id)
    setNovoAlvoValor(p.preco_alvo)
  }

  async function salvarEdicaoAlvo(id, e) {
    e.preventDefault()
    const valor = Number(String(novoAlvoValor).replace(',', '.'))
    if (!Number.isFinite(valor) || valor <= 0) return
    await acoes.salvarAlvo(id, Number(valor.toFixed(2)))
    setEditandoAlvoId(null)
  }

  return (
    <section className="saas-secao-produtos">
      {/* Barra de Ferramentas e Filtros */}
      <div className="saas-toolbar">
        <div className="saas-toolbar__filtros-status">
          {[
            { id: '', rotulo: 'Todos' },
            { id: 'alvo_atingido', rotulo: 'No Preço' },
            { id: 'aguardando', rotulo: 'Aguardando' },
            { id: 'pausado', rotulo: 'Pausados' },
            { id: 'erro', rotulo: 'Com Erro' },
          ].map((f) => (
            <button
              key={f.id}
              className={`saas-btn-filtro ${filtroStatus === f.id ? 'saas-btn-filtro--ativo' : ''}`}
              onClick={() => {
                setFiltroStatus(f.id)
                setPagina(1)
              }}
            >
              {f.rotulo}
            </button>
          ))}
        </div>

        <div className="saas-toolbar__controles-direita">
          <div className="saas-busca-wrapper">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
            <input
              type="search"
              className="saas-busca-input"
              placeholder="Buscar por produto ou loja…"
              value={busca}
              onChange={(e) => {
                setBusca(e.target.value)
                setPagina(1)
              }}
            />
            {busca && (
              <button className="saas-busca-limpar" onClick={() => setBusca('')}>
                ×
              </button>
            )}
          </div>

          <div className="saas-ordenacao-wrapper">
            <select
              className="saas-select"
              value={ordenacao}
              onChange={(e) => setOrdenacao(e.target.value)}
              title="Critério de Ordenação"
            >
              <option value="variacao_desc">Maior Desconto (%)</option>
              <option value="preco_asc">Menor Preço (R$)</option>
              <option value="preco_desc">Maior Preço (R$)</option>
              <option value="recente">Última Verificação</option>
              <option value="nome_asc">Nome (A-Z)</option>
            </select>
          </div>

          <div className="saas-view-switcher">
            <button
              className={`saas-view-btn ${modoVisualizacao === 'tabela' ? 'saas-view-btn--ativo' : ''}`}
              onClick={() => setModoVisualizacao('tabela')}
              title="Visualização em Tabela SaaS"
              aria-label="Tabela"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 3h18v18H3z" />
                <path d="M3 9h18" />
                <path d="M3 15h18" />
                <path d="M9 3v18" />
              </svg>
            </button>
            <button
              className={`saas-view-btn ${modoVisualizacao === 'grid' ? 'saas-view-btn--ativo' : ''}`}
              onClick={() => setModoVisualizacao('grid')}
              title="Visualização em Grid de Cards"
              aria-label="Cards"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect width="7" height="7" x="3" y="3" rx="1" />
                <rect width="7" height="7" x="14" y="3" rx="1" />
                <rect width="7" height="7" x="14" y="14" rx="1" />
                <rect width="7" height="7" x="3" y="14" rx="1" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Resultados da Listagem */}
      {produtosFiltrados.length === 0 ? (
        <div className="saas-vazio">
          <div className="saas-vazio__icone">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
              <path d="m7.5 4.27 9 5.15" />
              <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
              <path d="m3.3 7 8.7 5 8.7-5" />
              <path d="M12 22V12" />
            </svg>
          </div>
          <h3>Nenhum produto localizado</h3>
          <p>
            {busca || filtroStatus || filtroLoja
              ? 'Tente remover os filtros ou mudar os termos de busca.'
              : 'Você ainda não está monitorando nenhum item.'}
          </p>
          <button className="saas-botao saas-botao--primario" onClick={aoAbrirNovoProduto}>
            + Rastrear Primeiro Produto
          </button>
        </div>
      ) : modoVisualizacao === 'grid' ? (
        <div className="produtos">
          {produtosPaginados.map((produto) => (
            <CardProduto
              key={produto.id}
              produto={produto}
              ocupado={ocupados.has(produto.id)}
              aoPausar={acoes.pausar}
              aoRetomar={acoes.retomar}
              aoRemover={acoes.remover}
              aoColetar={acoes.coletar}
              aoSalvarAlvo={acoes.salvarAlvo}
              aoAbrirHistorico={aoAbrirHistorico}
            />
          ))}
        </div>
      ) : (
        <div className="saas-tabela-container">
          <table className="saas-tabela" aria-label="Tabela de Monitoramento de Preços">
            <thead>
              <tr>
                <th style={{ width: '36px' }} aria-label="Expandir" />
                <th>Produto & Loja</th>
                <th>Preço Atual</th>
                <th>Preço Alvo</th>
                <th>Status</th>
                <th>Última Coleta</th>
                <th style={{ textAlign: 'right' }}>Ações</th>
              </tr>
            </thead>
            <tbody>
              {produtosPaginados.map((p) => {
                const expandido = linhasExpandidas.has(p.id)
                const ocupado = ocupados.has(p.id)
                const atingido = p.status === 'alvo_atingido'
                const pausado = p.status === 'pausado'
                const comErro = p.status === 'erro'
                const variacao = p.variacao_percentual

                return (
                  <tr key={p.id} className={`saas-tabela__linha ${expandido ? 'saas-tabela__linha--expandida' : ''}`}>
                    <td colSpan="7" style={{ padding: 0 }}>
                      <div className="saas-tabela__linha-principal">
                        <button
                          className="saas-btn-expandir"
                          onClick={() => alternarExpansao(p.id)}
                          title={expandido ? 'Ocultar gráfico' : 'Expandir histórico e métricas'}
                          aria-expanded={expandido}
                        >
                          <svg
                            width="14"
                            height="14"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            style={{ transform: expandido ? 'rotate(90deg)' : 'none', transition: 'transform 0.15s ease' }}
                          >
                            <polyline points="9 18 15 12 9 6" />
                          </svg>
                        </button>

                        <div className="saas-celula-produto">
                          {p.imagem_url ? (
                            <img src={p.imagem_url} alt="" className="saas-celula-produto__thumb" loading="lazy" />
                          ) : (
                            <div className="saas-celula-produto__thumb-vazio">
                              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="m7.5 4.27 9 5.15" />
                                <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
                              </svg>
                            </div>
                          )}
                          <div className="saas-celula-produto__info">
                            <a
                              href={p.url}
                              target="_blank"
                              rel="noreferrer noopener"
                              className="saas-celula-produto__nome"
                              title={p.nome}
                            >
                              {p.nome}
                            </a>
                            <span className="saas-celula-produto__loja">
                              {p.loja || 'Loja Desconhecida'}
                            </span>
                          </div>
                        </div>

                        {/* Preço Atual e Variação */}
                        <div className="saas-celula-preco">
                          <strong className={`saas-preco-destaque ${atingido ? 'saas-preco-destaque--atingido' : ''}`}>
                            {brl(p.preco_atual)}
                          </strong>
                          {variacao !== null && variacao !== undefined && Math.abs(variacao) >= 0.1 && (
                            <span className={`saas-badge-variacao ${variacao <= 0 ? 'saas-badge-variacao--queda' : 'saas-badge-variacao--alta'}`}>
                              {variacao <= 0 ? '▼' : '▲'} {Math.abs(variacao).toFixed(1)}%
                            </span>
                          )}
                        </div>

                        {/* Preço Alvo (Editável Inline) */}
                        <div className="saas-celula-alvo">
                          {editandoAlvoId === p.id ? (
                            <form className="saas-inline-form" onSubmit={(e) => salvarEdicaoAlvo(p.id, e)}>
                              <input
                                type="number"
                                step="0.01"
                                min="0.01"
                                className="saas-inline-input"
                                value={novoAlvoValor}
                                onChange={(e) => setNovoAlvoValor(e.target.value)}
                                autoFocus
                              />
                              <button type="submit" className="saas-botao saas-botao--primario saas-botao--mini">
                                Salvar
                              </button>
                              <button
                                type="button"
                                className="saas-botao saas-botao--secundario saas-botao--mini"
                                onClick={() => setEditandoAlvoId(null)}
                              >
                                Cancelar
                              </button>
                            </form>
                          ) : (
                            <button
                              className="saas-alvo-clicavel"
                              onClick={() => iniciarEdicaoAlvo(p)}
                              title="Clique para editar a meta de preço"
                            >
                              <span>{brl(p.preco_alvo)}</span>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
                              </svg>
                            </button>
                          )}
                        </div>

                        {/* Status */}
                        <div className="saas-celula-status">
                          {atingido ? (
                            <span className="saas-badge saas-badge--sucesso">Alvo Atingido</span>
                          ) : pausado ? (
                            <span className="saas-badge saas-badge--neutro">Pausado</span>
                          ) : comErro ? (
                            <span className="saas-badge saas-badge--erro" title={p.ultimo_erro}>Falha Coleta</span>
                          ) : (
                            <span className="saas-badge saas-badge--azul">Aguardando</span>
                          )}
                        </div>

                        {/* Última Coleta */}
                        <div className="saas-celula-tempo" title={dataHora(p.ultima_coleta_em)}>
                          {tempoRelativo(p.ultima_coleta_em)}
                        </div>

                        {/* Ações Rápidas na Linha */}
                        <div className="saas-celula-acoes">
                          <button
                            className="saas-botao saas-botao--secundario saas-botao--mini"
                            onClick={() => acoes.coletar(p)}
                            disabled={ocupado}
                            title="Verificar preço na loja agora"
                          >
                            <svg className={ocupado ? 'saas-anim-spin' : ''} width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
                              <path d="M3 3v5h5" />
                              <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" />
                              <path d="M16 16h5v5" />
                            </svg>
                            <span>Verificar</span>
                          </button>

                          <button
                            className="saas-botao saas-botao--suave saas-botao--mini"
                            onClick={() => (pausado ? acoes.retomar(p) : acoes.pausar(p))}
                            disabled={ocupado}
                            title={pausado ? 'Retomar monitoramento' : 'Pausar alertas temporariamente'}
                          >
                            {pausado ? 'Retomar' : 'Pausar'}
                          </button>

                          <a
                            href={p.url}
                            target="_blank"
                            rel="noreferrer noopener"
                            className="saas-botao saas-botao--icone-mini saas-botao--suave"
                            title="Abrir no site da loja"
                          >
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                              <polyline points="15 3 21 3 21 9" />
                              <line x1="10" y1="14" x2="21" y2="3" />
                            </svg>
                          </a>

                          <button
                            className="saas-botao saas-botao--icone-mini saas-botao--perigo-suave"
                            onClick={() => acoes.remover(p)}
                            disabled={ocupado}
                            title="Remover produto da lista"
                          >
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M3 6h18" />
                              <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                              <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                            </svg>
                          </button>
                        </div>
                      </div>

                      {/* Sub-painel Expansível de Histórico & Métricas */}
                      {expandido && (
                        <div className="saas-painel-expandido">
                          <div className="saas-painel-expandido__metricas">
                            <div className="saas-metrica-bloco">
                              <span className="saas-metrica-bloco__label">Menor Preço Visto:</span>
                              <strong className="saas-metrica-bloco__valor saas-metrica-bloco__valor--verde">
                                {brl(p.menor_preco || p.preco_atual)}
                              </strong>
                            </div>
                            <div className="saas-metrica-bloco">
                              <span className="saas-metrica-bloco__label">Preço Inicial:</span>
                              <span className="saas-metrica-bloco__valor">{brl(p.preco_inicial)}</span>
                            </div>
                            <div className="saas-metrica-bloco">
                              <span className="saas-metrica-bloco__label">Maior Preço Visto:</span>
                              <span className="saas-metrica-bloco__valor">{brl(p.maior_preco || p.preco_atual)}</span>
                            </div>
                            <div className="saas-metrica-bloco">
                              <span className="saas-metrica-bloco__label">Total de Coletas:</span>
                              <span className="saas-metrica-bloco__valor">{p.total_coletas || 1} registros</span>
                            </div>
                            {p.fonte_preco && (
                              <div className="saas-metrica-bloco">
                                <span className="saas-metrica-bloco__label">Scraper Engine:</span>
                                <span className="saas-metrica-bloco__valor">
                                  {ROTULOS_FONTE[p.fonte_preco] || p.fonte_preco} ({Math.round((p.confianca ?? 0.9) * 100)}%)
                                </span>
                              </div>
                            )}
                          </div>

                          <div className="saas-painel-expandido__grafico-box">
                            <div className="saas-painel-expandido__grafico-topo">
                              <strong>Histórico de Variação de Preço</strong>
                              <button
                                className="saas-botao saas-botao--texto saas-botao--mini"
                                onClick={() => aoAbrirHistorico(p)}
                              >
                                Ver Histórico Completo em Modal ↗
                              </button>
                            </div>

                            {/* Renderização do gráfico SVG integrado */}
                            <GraficoHistorico
                              pontos={(p.serie || []).map((val, idx) => ({
                                preco: val,
                                coletado_em: p.ultima_coleta_em,
                              }))}
                              precoAlvo={p.preco_alvo}
                            />
                          </div>
                        </div>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Paginação */}
      {produtosFiltrados.length > itensPorPagina && (
        <div className="saas-paginacao">
          <span className="saas-paginacao__info">
            Mostrando {inicio + 1}–{Math.min(inicio + itensPorPagina, produtosFiltrados.length)} de{' '}
            {produtosFiltrados.length} produtos
          </span>
          <div className="saas-paginacao__botoes">
            <button
              className="saas-botao saas-botao--suave saas-botao--mini"
              onClick={() => setPagina((p) => Math.max(1, p - 1))}
              disabled={paginaAjustada === 1}
            >
              Anterior
            </button>
            <span className="saas-paginacao__pagina-atual">
              Página {paginaAjustada} de {totalPaginas}
            </span>
            <button
              className="saas-botao saas-botao--suave saas-botao--mini"
              onClick={() => setPagina((p) => Math.min(totalPaginas, p + 1))}
              disabled={paginaAjustada === totalPaginas}
            >
              Próxima
            </button>
          </div>
        </div>
      )}
    </section>
  )
}
