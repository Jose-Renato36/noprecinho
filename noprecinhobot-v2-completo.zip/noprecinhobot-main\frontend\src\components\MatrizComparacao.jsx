import { useState, useMemo } from 'react'
import { brl } from '../utils'

export default function MatrizComparacao({ produtos = [], aoAbrirNovoProduto }) {
  const [busca, setBusca] = useState('')

  // Agrupa produtos por similaridade de nome ou categoria
  const grupos = useMemo(() => {
    if (!produtos.length) return []

    // Agrupamento por palavras-chave principais do nome
    const mapa = new Map()

    produtos.forEach((p) => {
      // Normalização de chave de comparação (primeiras 3 palavras relevantes)
      const chave = p.nome
        ? p.nome
            .toLowerCase()
            .replace(/[^\w\s]/gi, '')
            .split(/\s+/)
            .slice(0, 3)
            .join(' ')
        : 'Outros'

      if (!mapa.has(chave)) {
        mapa.set(chave, [])
      }
      mapa.get(chave).push(p)
    })

    const lista = []
    mapa.forEach((itens, chave) => {
      lista.push({
        chave,
        titulo: itens[0].nome,
        itens,
      })
    })

    return lista
  }, [produtos])

  const gruposFiltrados = useMemo(() => {
    if (!busca) return grupos
    const termo = busca.toLowerCase()
    return grupos.filter((g) =>
      g.titulo.toLowerCase().includes(termo) ||
      g.itens.some((i) => i.loja?.toLowerCase().includes(termo))
    )
  }, [grupos, busca])

  return (
    <div className="saas-secao-matriz">
      <div className="saas-cabecalho-pagina">
        <div>
          <h2>Matriz Comparativa Multi-Lojas</h2>
          <p className="saas-subtitulo-pagina">
            Compare o mesmo item rastreado em diferentes e-commerces em colunas lado a lado para encontrar o menor preço.
          </p>
        </div>

        <div className="saas-busca-wrapper">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <input
            type="search"
            className="saas-busca-input"
            placeholder="Filtrar comparações…"
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
          />
        </div>
      </div>

      {gruposFiltrados.length === 0 ? (
        <div className="saas-vazio">
          <div className="saas-vazio__icone">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
              <path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
              <path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
              <path d="M7 21h10" />
              <path d="M12 3v18" />
              <path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2" />
            </svg>
          </div>
          <h3>Nenhum grupo de comparação encontrado</h3>
          <p>Cadastre links do mesmo produto em lojas diferentes (ex: Kabum, Amazon, Mercado Livre) para comparar lado a lado.</p>
          <button className="saas-botao saas-botao--primario" onClick={aoAbrirNovoProduto}>
            + Rastrear Produto
          </button>
        </div>
      ) : (
        <div className="saas-matriz-grid">
          {gruposFiltrados.map((grupo) => {
            // Identifica o menor preço no grupo
            const menorPreco = Math.min(...grupo.itens.map((i) => Number(i.preco_atual || Infinity)))
            const maiorPreco = Math.max(...grupo.itens.map((i) => Number(i.preco_atual || 0)))
            const diferencaTotal = maiorPreco > menorPreco && Number.isFinite(menorPreco) ? maiorPreco - menorPreco : 0

            return (
              <article key={grupo.chave} className="saas-card-matriz">
                <header className="saas-card-matriz__topo">
                  <div className="saas-card-matriz__titulo-grupo">
                    <h3>{grupo.titulo}</h3>
                    <span className="saas-badge saas-badge--azul">
                      {grupo.itens.length} {grupo.itens.length === 1 ? 'loja rastreada' : 'lojas rastreadas'}
                    </span>
                  </div>

                  {diferencaTotal > 0 && (
                    <div className="saas-card-matriz__spread">
                      <span>Diferença entre lojas:</span>
                      <strong className="saas-spread-valor">
                        {brl(diferencaTotal)} ({Math.round((diferencaTotal / maiorPreco) * 100)}% de spread)
                      </strong>
                    </div>
                  )}
                </header>

                <div className="saas-matriz-colunas">
                  {grupo.itens.map((item) => {
                    const preco = Number(item.preco_atual || 0)
                    const ehMenor = preco === menorPreco && Number.isFinite(menorPreco)
                    const distanciaMenor = preco - menorPreco

                    return (
                      <div
                        key={item.id}
                        className={`saas-matriz-loja-card ${ehMenor ? 'saas-matriz-loja-card--campeao' : ''}`}
                      >
                        <div className="saas-matriz-loja-card__cabecalho">
                          <span className="saas-loja-tag">{item.loja || 'E-commerce'}</span>
                          {ehMenor && (
                            <span className="saas-badge saas-badge--sucesso">
                              Menor Preço
                            </span>
                          )}
                        </div>

                        <div className="saas-matriz-loja-card__foto">
                          {item.imagem_url ? (
                            <img src={item.imagem_url} alt="" loading="lazy" />
                          ) : (
                            <div className="saas-sem-foto">
                              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
                                <path d="m7.5 4.27 9 5.15" />
                                <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
                              </svg>
                            </div>
                          )}
                        </div>

                        <div className="saas-matriz-loja-card__preco-box">
                          <span className="saas-matriz-loja-card__label">Preço Atual:</span>
                          <strong className={`saas-matriz-loja-card__preco ${ehMenor ? 'saas-matriz-loja-card__preco--menor' : ''}`}>
                            {brl(item.preco_atual)}
                          </strong>
                          {!ehMenor && distanciaMenor > 0 && (
                            <span className="saas-matriz-loja-card__diferenca">
                              +{brl(distanciaMenor)} mais caro
                            </span>
                          )}
                        </div>

                        <div className="saas-matriz-loja-card__alvo">
                          <span>Sua meta: <strong>{brl(item.preco_alvo)}</strong></span>
                        </div>

                        <div className="saas-matriz-loja-card__acoes">
                          <a
                            href={item.url}
                            target="_blank"
                            rel="noreferrer noopener"
                            className="saas-botao saas-botao--primario saas-botao--bloco saas-botao--mini"
                          >
                            <span>Comprar nesta Loja</span>
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginLeft: '4px' }}>
                              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                              <polyline points="15 3 21 3 21 9" />
                              <line x1="10" y1="14" x2="21" y2="3" />
                            </svg>
                          </a>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </article>
            )
          })}
        </div>
      )}
    </div>
  )
}
