import { useState, useMemo } from 'react'
import { brl, tempoRelativo, dataHora } from '../utils'

export default function DrawerAlertas({
  aberto,
  aoFechar,
  alertas = [],
  emailAtivo = false,
  aoMarcarLido,
  aoMarcarTodos,
  aoRemover,
}) {
  const [filtro, setFiltro] = useState('todos') // 'todos' | 'nao_lidos'

  const alertasFiltrados = useMemo(() => {
    if (filtro === 'nao_lidos') {
      return alertas.filter((a) => !a.lido)
    }
    return alertas
  }, [alertas, filtro])

  const naoLidos = alertas.filter((a) => !a.lido).length

  if (!aberto) return null

  return (
    <div className="saas-drawer-backdrop" onClick={aoFechar}>
      <div
        className="saas-drawer saas-drawer--direita"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-label="Feed de Notificações e Alertas"
      >
        <div className="saas-drawer__cabecalho">
          <div className="saas-drawer__titulo-grupo">
            <div className="saas-drawer__icone-alerta">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
                <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
              </svg>
            </div>
            <div>
              <h3>Alertas & Quedas</h3>
              <span className="saas-drawer__subtitulo">
                {naoLidos > 0 ? `${naoLidos} novo(s) disparo(s)` : 'Nenhuma notificação pendente'}
              </span>
            </div>
          </div>

          <div className="saas-drawer__acoes-topo">
            {naoLidos > 0 && (
              <button
                className="saas-botao saas-botao--texto saas-botao--compacto"
                onClick={aoMarcarTodos}
                title="Marcar todos como lidos"
              >
                Marcar lidos
              </button>
            )}
            <button
              className="saas-drawer__fechar"
              onClick={aoFechar}
              aria-label="Fechar painel"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 6 6 18" />
                <path d="m6 6 12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Filtro Rápido */}
        <div className="saas-drawer__filtros">
          <button
            className={`saas-chip ${filtro === 'todos' ? 'saas-chip--ativo' : ''}`}
            onClick={() => setFiltro('todos')}
          >
            Todos ({alertas.length})
          </button>
          <button
            className={`saas-chip ${filtro === 'nao_lidos' ? 'saas-chip--ativo' : ''}`}
            onClick={() => setFiltro('nao_lidos')}
          >
            Não lidos ({naoLidos})
          </button>
        </div>

        {/* Lista de Alertas */}
        <div className="saas-drawer__corpo">
          {alertasFiltrados.length === 0 ? (
            <div className="saas-vazio saas-vazio--compacto">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <path d="m9 12 2 2 4-4" />
              </svg>
              <p>
                {filtro === 'nao_lidos'
                  ? 'Você já leu todos os alertas.'
                  : 'Nenhum alerta registrado ainda. Quando um produto atingir o preço desejado, ele aparecerá aqui.'}
              </p>
            </div>
          ) : (
            <div className="saas-feed-alertas">
              {alertasFiltrados.map((alerta) => {
                const economia = Number(alerta.preco_alvo) - Number(alerta.preco_disparo)
                return (
                  <article
                    key={alerta.id}
                    className={`saas-card-alerta ${!alerta.lido ? 'saas-card-alerta--nao-lido' : ''}`}
                  >
                    <div className="saas-card-alerta__lateral">
                      {alerta.produto?.imagem_url ? (
                        <img
                          src={alerta.produto.imagem_url}
                          alt=""
                          className="saas-card-alerta__thumb"
                          loading="lazy"
                        />
                      ) : (
                        <div className="saas-card-alerta__thumb-vazio">
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="m7.5 4.27 9 5.15" />
                            <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
                          </svg>
                        </div>
                      )}
                    </div>

                    <div className="saas-card-alerta__conteudo">
                      <div className="saas-card-alerta__cabecalho">
                        <span className="saas-card-alerta__horario" title={dataHora(alerta.criado_em)}>
                          {tempoRelativo(alerta.criado_em)}
                        </span>
                        {!alerta.lido && <span className="saas-ponto-novo" title="Não lido" />}
                      </div>

                      <h4 className="saas-card-alerta__titulo" title={alerta.produto?.nome}>
                        {alerta.produto?.nome ?? 'Produto Monitorado'}
                      </h4>

                      <div className="saas-card-alerta__precos">
                        <div className="saas-card-alerta__preco-item">
                          <span className="saas-card-alerta__preco-label">Preço Detectado:</span>
                          <strong className="saas-card-alerta__preco-valor saas-card-alerta__preco-valor--destaque">
                            {brl(alerta.preco_disparo)}
                          </strong>
                        </div>
                        <div className="saas-card-alerta__preco-item">
                          <span className="saas-card-alerta__preco-label">Meta Definida:</span>
                          <span className="saas-card-alerta__preco-alvo">{brl(alerta.preco_alvo)}</span>
                        </div>
                      </div>

                      {economia > 0 && (
                        <div className="saas-card-alerta__badge-economia">
                          Economia de {brl(economia)} abaixo do seu alvo!
                        </div>
                      )}

                      <div className="saas-card-alerta__rodape">
                        {alerta.produto?.url && (
                          <a
                            href={alerta.produto.url}
                            target="_blank"
                            rel="noreferrer noopener"
                            className="saas-botao saas-botao--primario saas-botao--mini"
                          >
                            <span>Ir para Loja</span>
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginLeft: '4px' }}>
                              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                              <polyline points="15 3 21 3 21 9" />
                              <line x1="10" y1="14" x2="21" y2="3" />
                            </svg>
                          </a>
                        )}

                        {!alerta.lido && (
                          <button
                            className="saas-botao saas-botao--suave saas-botao--mini"
                            onClick={() => aoMarcarLido(alerta.id)}
                          >
                            Marcar lido
                          </button>
                        )}

                        <button
                          className="saas-botao saas-botao--icone-mini saas-botao--perigo-suave"
                          onClick={() => aoRemover(alerta.id)}
                          title="Remover alerta"
                          aria-label="Remover alerta"
                        >
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M3 6h18" />
                            <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                            <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </article>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
