import { useState } from 'react'
import { api } from '../api'
import Etiqueta from './Etiqueta'

// A mesma tela serve para entrar e para criar conta: são os mesmos campos, menos
// o nome. Duas telas separadas só duplicariam formulário e validação.
export default function TelaLogin({ aoEntrar }) {
  const [modo, setModo] = useState('login')
  const [nome, setNome] = useState('')
  const [email, setEmail] = useState(() => {
    try {
      return localStorage.getItem('noprecinho_ultimo_email') || ''
    } catch {
      return ''
    }
  })
  const [senha, setSenha] = useState('')
  const [lembrar, setLembrar] = useState(true)
  const [erro, setErro] = useState(null)
  const [enviando, setEnviando] = useState(false)

  const criandoConta = modo === 'registro'

  async function enviar(evento) {
    evento.preventDefault()
    setErro(null)

    if (criandoConta && senha.length < 8) {
      setErro('A senha precisa de pelo menos 8 caracteres.')
      return
    }

    setEnviando(true)
    try {
      const resposta = criandoConta
        ? await api.registrar(nome.trim(), email.trim(), senha)
        : await api.login(email.trim(), senha)

      try {
        if (lembrar) {
          localStorage.setItem('noprecinho_ultimo_email', email.trim())
          localStorage.setItem('noprecinho_lembrar', '1')
        } else {
          localStorage.removeItem('noprecinho_ultimo_email')
          localStorage.removeItem('noprecinho_lembrar')
        }
      } catch {
        /* storage fallback */
      }

      // O token vem no corpo, mas o painel o ignora: quem carrega a sessão é o
      // cookie httpOnly que o servidor gravou com duração de 30 dias.
      aoEntrar(resposta.usuario)
    } catch (e) {
      setErro(e.message)
    } finally {
      setEnviando(false)
    }
  }

  function trocarModo() {
    setModo(criandoConta ? 'login' : 'registro')
    setErro(null)
    setSenha('')
  }

  return (
    <div className="login">
      <div className="login__cartao">
        <div className="login__marca">
          <Etiqueta className="login__logo" />
          <h1>
            No<span>Precinho</span>Bot
          </h1>
          <p>Você diz o preço. Ele vigia até chegar lá.</p>
        </div>

        <form className="login__form" onSubmit={enviar}>
          <h2>{criandoConta ? 'Criar conta' : 'Entrar'}</h2>

          {criandoConta && (
            <div className="campo">
              <label htmlFor="login-nome">Nome</label>
              <input
                id="login-nome"
                type="text"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                placeholder="Como quer ser chamado"
                required
                maxLength={120}
                autoComplete="name"
              />
            </div>
          )}

          <div className="campo">
            <label htmlFor="login-email">E-mail</label>
            <input
              id="login-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="voce@exemplo.com"
              required
              autoComplete="email"
            />
          </div>

          <div className="campo">
            <label htmlFor="login-senha">Senha</label>
            <input
              id="login-senha"
              type="password"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              placeholder={criandoConta ? 'Mínimo de 8 caracteres' : '••••••••'}
              required
              maxLength={72}
              autoComplete={criandoConta ? 'new-password' : 'current-password'}
            />
          </div>

          {/* Opção Permanecer Conectado */}
          <div className="login__lembrar-container">
            <label className="login__lembrar-rotulo">
              <input
                type="checkbox"
                checked={lembrar}
                onChange={(e) => setLembrar(e.target.checked)}
                className="login__lembrar-checkbox"
              />
              <span>Permanecer sempre conectado</span>
            </label>
            <span className="login__lembrar-dica">
              Sua sessão permanecerá salva neste dispositivo para você não precisar logar novamente.
            </span>
          </div>

          {erro && <p className="login__erro">{erro}</p>}

          <button className="botao botao--primario login__enviar" type="submit" disabled={enviando}>
            {enviando ? 'Aguarde…' : criandoConta ? 'Criar conta e entrar' : 'Entrar'}
          </button>

          <p className="login__troca">
            {criandoConta ? 'Já tem conta?' : 'Ainda não tem conta?'}{' '}
            <button type="button" className="login__link" onClick={trocarModo}>
              {criandoConta ? 'Entrar' : 'Criar uma agora'}
            </button>
          </p>
        </form>

        <p className="login__nota">Cada conta vê apenas os próprios produtos.</p>
      </div>
    </div>
  )
}
