import { useState, useRef, useEffect } from 'react'

export default function Topbar({
  usuario,
  aoSair,
  falhaConexao,
  naoLidos,
  aoAlternarAlertas,
  aoAbrirNovoProduto,
  aoColetarTudo,
  coletando,
  aoAlternarSidebarMobile,
  filtroLoja,
  aoMudarFiltroLoja,
  lojasDisponiveis = [],
  aoAbrirPerfil,
  aoAbrirConfiguracoes,
  aoTrocarConta,
  tema,
  aoAlternarTema,
}) {
  const [menuUsuarioAberto, setMenuUsuarioAberto] = useState(false)
  const menuRef = useRef(null)

  useEffect(() => {
    function aoClicarFora(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuUsuarioAberto(false)
      }
    }
    document.addEventListener('mousedown', aoClicarFora)
    return () => document.removeEventListener('mousedown', aoClicarFora)
  }, [])

  return (
    <header className="saas-topbar">
      <div className="saas-topbar__esquerda">
        <button
          className="saas-topbar__hamburguer"
          onClick={aoAlternarSidebarMobile}
          aria-label="Abrir menu"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="4" x2="20" y1="12" y2="12" />
            <line x1="4" x2="20" y1="6" y2="6" />
            <line x1="4" x2="20" y1="18" y2="18" />
          </svg>
        </button>

        <div className="saas-topbar__loja-seletor">
          <label htmlFor="topbar-loja" className="saas-topbar__loja-label">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
              <polyline points="9 22 9 12 15 12 15 22" />
            </svg>
            <span>Workspace:</span>
          </label>
          <select
            id="topbar-loja"
            className="saas-topbar__select"
            value={filtroLoja}
            onChange={(e) => aoMudarFiltroLoja(e.target.value)}
          >
            <option value="">Todas as Lojas ({lojasDisponiveis.length})</option>
            {lojasDisponiveis.map((loja) => (
              <option key={loja.loja} value={loja.loja}>
                {loja.loja} ({loja.total_produtos})
              </option>
            ))}
          </select>
        </div>

        {falhaConexao && (
          <div className="saas-topbar__status-conexao" title={`Erro: ${falhaConexao}`}>
            <span className="saas-badge saas-badge--erro">
              <span className="saas-ponto-status saas-ponto-status--vermelho" />
              API Desconectada
            </span>
          </div>
        )}
      </div>

      <div className="saas-topbar__direita">
        <button
          className="saas-botao saas-botao--secundario saas-botao--compacto"
          onClick={aoColetarTudo}
          disabled={coletando}
          title="Disparar scraper em todos os produtos agora"
        >
          <svg
            className={coletando ? 'saas-anim-spin' : ''}
            width="15"
            height="15"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
            <path d="M3 3v5h5" />
            <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" />
            <path d="M16 16h5v5" />
          </svg>
          <span>{coletando ? 'Varrendo lojas…' : 'Coletar Tudo'}</span>
        </button>

        <button
          className="saas-botao saas-botao--primario saas-botao--compacto"
          onClick={aoAbrirNovoProduto}
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M5 12h14" />
            <path d="M12 5v14" />
          </svg>
          <span>Novo Alerta</span>
        </button>

        {/* Alternador de Tema Claro / Escuro */}
        <button
          className="saas-topbar__icone-botao"
          onClick={aoAlternarTema}
          title={tema === 'dark' ? 'Mudar para Modo Claro (Branco)' : 'Mudar para Modo Escuro (Preto)'}
          aria-label="Alternar tema de cores"
        >
          {tema === 'dark' ? (
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: '#FBBF24' }}>
              <circle cx="12" cy="12" r="4" />
              <path d="M12 2v2" />
              <path d="M12 20v2" />
              <path d="m4.93 4.93 1.41 1.41" />
              <path d="m17.66 17.66 1.41 1.41" />
              <path d="M2 12h2" />
              <path d="M20 12h2" />
              <path d="m6.34 17.66-1.41 1.41" />
              <path d="m19.07 4.93-1.41 1.41" />
            </svg>
          ) : (
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" />
            </svg>
          )}
        </button>

        {/* Notificações Bell com Drawer Trigger */}
        <button
          className="saas-topbar__icone-botao"
          onClick={aoAlternarAlertas}
          title="Notificações e Alertas em Tempo Real"
          aria-label="Abrir notificações"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
            <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
          </svg>
          {naoLidos > 0 && (
            <span className="saas-topbar__sino-badge">
              {naoLidos > 99 ? '99+' : naoLidos}
            </span>
          )}
        </button>

        <div className="saas-topbar__divisor" />

        {/* Perfil do Usuário */}
        <div className="saas-perfil-menu" ref={menuRef}>
          <button
            className="saas-perfil-menu__gatilho"
            onClick={() => setMenuUsuarioAberto((v) => !v)}
            aria-expanded={menuUsuarioAberto}
          >
            <div className="saas-avatar">
              {usuario.nome ? usuario.nome.slice(0, 2).toUpperCase() : 'US'}
            </div>
            <div className="saas-perfil-menu__meta">
              <strong className="saas-perfil-menu__nome">{usuario.nome}</strong>
              <span className="saas-perfil-menu__email">{usuario.email}</span>
            </div>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="m6 9 6 6 6-6" />
            </svg>
          </button>

          {menuUsuarioAberto && (
            <div className="saas-dropdown saas-dropdown--direita">
              <div className="saas-dropdown__cabecalho">
                <strong>{usuario.nome}</strong>
                <span>{usuario.email}</span>
              </div>
              <div className="saas-dropdown__divisor" />
              <button
                className="saas-dropdown__item"
                onClick={() => {
                  setMenuUsuarioAberto(false)
                  aoAbrirPerfil?.()
                }}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
                <span>Meu Perfil</span>
              </button>
              <button
                className="saas-dropdown__item"
                onClick={() => {
                  setMenuUsuarioAberto(false)
                  aoAbrirConfiguracoes?.()
                }}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                  <circle cx="12" cy="12" r="3" />
                </svg>
                <span>Configurações</span>
              </button>
              <button
                className="saas-dropdown__item"
                onClick={() => {
                  setMenuUsuarioAberto(false)
                  aoTrocarConta?.()
                }}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
                <span>Trocar de Conta</span>
              </button>
              <button
                className="saas-dropdown__item saas-dropdown__item--perigo"
                onClick={() => {
                  setMenuUsuarioAberto(false)
                  aoSair()
                }}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                  <polyline points="16 17 21 12 16 7" />
                  <line x1="21" x2="9" y1="12" y2="12" />
                </svg>
                <span>Encerrar Sessão</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
