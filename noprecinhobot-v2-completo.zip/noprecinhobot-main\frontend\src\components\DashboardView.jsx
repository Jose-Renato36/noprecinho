import { brl, tempoRelativo, contagemRegressiva } from '../utils'
import TabelaProdutos from './TabelaProdutos'

export default function DashboardView({
  resumo,
  produtos = [],
  alertas = [],
  lojas = [],
  ocupados = new Set(),
  acoes,
  aoAbrirHistorico,
  aoAbrirNovoProduto,
  aoMudarAba,
  filtroLoja,
  aoColetarTudo,
  coletando,
}) {
  const total = resumo?.total_produtos ?? produtos.length
  const noPreco = resumo?.alvo_atingido ?? produtos.filter((p) => p.status === 'alvo_atingido').length
  const aguardando = resumo?.aguardando ?? produtos.filter((p) => p.status === 'aguardando').length
  const comErro = resumo?.com_erro ?? produtos.filter((p) => p.status === 'erro').length
  const economia = resumo?.economia_potencial ?? 0

  // Cálculo da saúde média das lojas
  const taxaSucessoMedia = lojas.length
    ? Math.round((lojas.reduce((acc, l) => acc + (l.taxa_sucesso || 0), 0) / lojas.length) * 100)
    : 100

  return (
    <div className="saas-dashboard">
      {/* KPI Cards de Alta Densidade */}
      <div className="saas-kpi-grid">
        <div className="saas-kpi-card">
          <div className="saas-kpi-card__topo">
            <span className="saas-kpi-card__label">Monitoramento Ativo</span>
            <span className="saas-kpi-card__icone-mini">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m7.5 4.27 9 5.15" />
                <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
                <path d="m3.3 7 8.7 5 8.7-5" />
                <path d="M12 22V12" />
              </svg>
            </span>
          </div>
          <strong className="saas-kpi-card__valor">{total}</strong>
          <div className="saas-kpi-card__meta">
            <span>{aguardando} vigiando</span> · <span>{noPreco} no preço</span>
          </div>
        </div>

        <div className={`saas-kpi-card ${noPreco > 0 ? 'saas-kpi-card--verde' : ''}`}>
          <div className="saas-kpi-card__topo">
            <span className="saas-kpi-card__label">Oportunidades (Alvo Atingido)</span>
            <span className="saas-kpi-card__icone-mini">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <circle cx="12" cy="12" r="6" />
                <circle cx="12" cy="12" r="2" />
              </svg>
            </span>
          </div>
          <strong className="saas-kpi-card__valor">{noPreco}</strong>
          <div className="saas-kpi-card__meta">
            {noPreco > 0 ? (
              <span className="saas-texto-destaque-verde">Prontos para compra</span>
            ) : (
              <span>Nenhum alvo atingido ainda</span>
            )}
          </div>
        </div>

        <div className="saas-kpi-card">
          <div className="saas-kpi-card__topo">
            <span className="saas-kpi-card__label">Economia Potencial</span>
            <span className="saas-kpi-card__icone-mini">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="12" x2="12" y1="2" y2="22" />
                <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
              </svg>
            </span>
          </div>
          <strong className="saas-kpi-card__valor">{brl(economia)}</strong>
          <div className="saas-kpi-card__meta">
            <span>Queda acumulada desde o cadastro</span>
          </div>
        </div>

        <div className="saas-kpi-card">
          <div className="saas-kpi-card__topo">
            <span className="saas-kpi-card__label">Saúde dos Scrapers</span>
            <span className="saas-kpi-card__icone-mini">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.48 12H2" />
              </svg>
            </span>
          </div>
          <strong className="saas-kpi-card__valor">{taxaSucessoMedia}%</strong>
          <div className="saas-kpi-card__meta">
            {comErro > 0 ? (
              <span className="saas-texto-destaque-vermelho">{comErro} com falha</span>
            ) : (
              <span className="saas-texto-destaque-verde">Todas as lojas respondendo</span>
            )}
          </div>
        </div>

        <div className="saas-kpi-card">
          <div className="saas-kpi-card__topo">
            <span className="saas-kpi-card__label">Próxima Coleta</span>
            <span className="saas-kpi-card__icone-mini">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <polyline points="12 6 12 12 16 14" />
              </svg>
            </span>
          </div>
          <strong className="saas-kpi-card__valor saas-kpi-card__valor--medio">
            {resumo?.proxima_coleta_em
              ? contagemRegressiva(resumo.proxima_coleta_em)
              : 'Automático'}
          </strong>
          <div className="saas-kpi-card__meta">
            <span>
              {resumo?.agendador_ativo
                ? `Ciclo de ${resumo?.intervalo_minutos ?? 60} min`
                : 'Disparo manual'}
            </span>
          </div>
        </div>
      </div>

      {/* Grid Principal do Dashboard */}
      <div className="saas-dashboard__grid-secoes">
        {/* Tabela de Produtos */}
        <div className="saas-dashboard__coluna-principal">
          <div className="saas-bloco-secao">
            <div className="saas-bloco-secao__cabecalho">
              <div>
                <h3>Produtos Rastreados & Variação em Tempo Real</h3>
                <span className="saas-bloco-secao__subtitulo">
                  Clique na linha para expandir o gráfico e métricas detalhadas
                </span>
              </div>
            </div>

            <TabelaProdutos
              produtos={produtos}
              ocupados={ocupados}
              acoes={acoes}
              aoAbrirHistorico={aoAbrirHistorico}
              aoAbrirNovoProduto={aoAbrirNovoProduto}
              filtroLoja={filtroLoja}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
