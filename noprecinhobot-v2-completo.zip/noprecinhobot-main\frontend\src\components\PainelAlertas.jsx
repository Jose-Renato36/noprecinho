import { useState, useMemo } from 'react'
import { brl, dataHora, tempoRelativo } from '../utils'

export default function PainelAlertas({
  alertas = [],
  aoMarcarLido,
  aoMarcarTodos,
  aoRemover,
  emailAtivo = false,
}) {
  const [filtro, setFiltro] = useState('todos') // 'todos' | 'nao_lidos'
  const [busca, setBusca] = useState('')

  const naoLidos = alertas.filter((a) => !a.lido).length

  const alertasFiltrados = useMemo(() => {
    return alertas.filter((a) => {
      if (filtro === 'nao_lidos' && a.lido) return false
      if (busca) {
        const termo = busca.toLowerCase()
        const matchMsg = a.mensagem?.toLowerCase().includes(termo)
        const matchNome = a.produto?.nome?.toLowerCase().includes(termo)
        if (!matchMsg && !matchNome) return false
      }
      return true
    })
  }, [alertas, filtro, busca])

  return (
    <div className="saas-secao-alertas">
      <div className="saas-cabecalho-pagina">
        <div>
          <h2>Feed & Histórico de Alertas de Preço</h2>
          <p className="saas-subtitulo-pagina">
            Registro cronológico de todos os disparos ocorridos quando o valor de um item atingiu a meta estipulada.
          </p>
        </div>

        {naoLidos > 0 && (
          <button className="saas-botao saas-botao--secundario" onClick={aoMarcarTodos}>
            Marcar todos como lidos ({naoLidos})
          </button>
        )}
      </div>

      {/* Toolbar com Filtros */}
      <div className="saas-toolbar">
        <div className="saas-toolbar__filtros-status">
          <button
            className={`saas-btn-filtro ${filtro === 'todos' ? 'saas-btn-filtro--ativo' : ''}`}
            onClick={() => setFiltro('todos')}
          >
            Todos os Alertas ({alertas.length})
          </button>
          <button
            className={`saas-btn-filtro ${filtro === 'nao_lidos' ? 'saas-btn-filtro--ativo' : ''}`}
            onClick={() => setFiltro('nao_lidos')}
          >
            Não Lidos ({naoLidos})
          </button>
        </div>

        <div className="saas-busca-wrapper">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <input
            type="search"
            className="saas-busca-input"
            placeholder="Filtrar por produto ou mensagem…"
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
          />
        </div>
      </div>

      {alertasFiltrados.length === 0 ? (
        <div className="saas-vazio">
          <div className="saas-vazio__icone">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
              <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
              <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
            </svg>
          </div>
          <h3>Nenhum alerta para exibir</h3>
          <p>
            {filtro === 'nao_lidos'
              ? 'Todos os alertas já foram marcados como lidos.'
              : 'Nenhum alerta disparado ainda. Quando o preço de um item baixar para o seu alvo, ele aparecerá aqui.'}
          </p>
        </div>
      ) : (
        <div className="saas-lista-alertas-completa">
          {alertasFiltrados.map((alerta) => {
            const economia = Number(alerta.preco_alvo) - Number(alerta.preco_disparo)

            return (
              <article
                key={alerta.id}
                className={`saas-item-alerta-linha ${!alerta.lido ? 'saas-item-alerta-linha--nao-lido' : ''}`}
              >
                <div className="saas-item-alerta-linha__thumb-box">
                  {alerta.produto?.imagem_url ? (
                    <img src={alerta.produto.imagem_url} alt="" className="saas-item-alerta-linha__thumb" loading="lazy" />
                  ) : (
                    <div className="saas-item-alerta-linha__thumb-vazio">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="m7.5 4.27 9 5.15" />
                        <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
                      </svg>
                    </div>
                  )}
                </div>

                <div className="saas-item-alerta-linha__corpo">
                  <div className="saas-item-alerta-linha__topo">
                    <strong className="saas-item-alerta-linha__titulo">
                      {alerta.produto?.nome ?? 'Produto Monitorado'}
                    </strong>
                    <span className="saas-item-alerta-linha__horario" title={dataHora(alerta.criado_em)}>
                      {tempoRelativo(alerta.criado_em)}
                    </span>
                  </div>

                  <p className="saas-item-alerta-linha__msg">{alerta.mensagem}</p>

                  <div className="saas-item-alerta-linha__valores">
                    <span>
                      Disparou em: <strong>{brl(alerta.preco_disparo)}</strong>
                    </span>
                    <span>
                      Meta: <strong>{brl(alerta.preco_alvo)}</strong>
                    </span>
                    {economia > 0 && (
                      <span className="saas-badge saas-badge--sucesso">
                        {brl(economia)} abaixo do alvo
                      </span>
                    )}
                    {emailAtivo && (
                      <span className={`saas-badge ${alerta.email_enviado ? 'saas-badge--sucesso' : 'saas-badge--neutro'}`}>
                        {alerta.email_enviado ? 'E-mail disparado' : 'Local'}
                      </span>
                    )}
                  </div>
                </div>

                <div className="saas-item-alerta-linha__acoes">
                  {alerta.produto?.url && (
                    <a
                      href={alerta.produto.url}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="saas-botao saas-botao--primario saas-botao--mini"
                    >
                      <span>Ver na Loja</span>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginLeft: '4px' }}>
                        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                        <polyline points="15 3 21 3 21 9" />
                        <line x1="10" y1="14" x2="21" y2="3" />
                      </svg>
                    </a>
                  )}

                  {!alerta.lido && (
                    <button
                      className="saas-botao saas-botao--suave saas-botao--mini"
                      onClick={() => aoMarcarLido(alerta.id)}
                    >
                      Marcar lido
                    </button>
                  )}

                  <button
                    className="saas-botao saas-botao--icone-mini saas-botao--perigo-suave"
                    onClick={() => aoRemover(alerta.id)}
                    title="Excluir alerta"
                  >
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M3 6h18" />
                      <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                      <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                    </svg>
                  </button>
                </div>
              </article>
            )
          })}
        </div>
      )}
    </div>
  )
}
