import { useState } from 'react'
import { brl, dataHora } from '../utils'

export default function PerfilUsuario({ usuario, produtos = [], alertas = [], resumo, aoSair, aoTrocarConta, avisar }) {
  const [editando, setEditando] = useState(false)
  const [nome, setNome] = useState(usuario?.nome || '')
  const [salvando, setSalvando] = useState(false)

  const totalProdutos = produtos.length
  const alvosAtingidos = produtos.filter((p) => p.status === 'alvo_atingido').length
  const totalAlertas = alertas.length
  const economia = resumo?.economia_potencial ?? 0

  function salvarPerfil(e) {
    e.preventDefault()
    setSalvando(true)
    setTimeout(() => {
      setSalvando(false)
      setEditando(false)
      avisar('sucesso', 'Nome de perfil atualizado localmente com sucesso!')
    }, 400)
  }

  return (
    <div className="saas-secao-perfil">
      <div className="saas-cabecalho-pagina">
        <div>
          <h2>Perfil do Usuário & Segurança da Conta</h2>
          <p className="saas-subtitulo-pagina">
            Gerencie seus dados de acesso, estatísticas de uso e parâmetros de autenticação segura.
          </p>
        </div>
      </div>

      <div className="saas-config-grid">
        {/* Card Principal de Perfil */}
        <section className="saas-card-config">
          <header className="saas-card-config__topo">
            <div className="saas-avatar saas-avatar--grande">
              {usuario?.nome ? usuario.nome.slice(0, 2).toUpperCase() : 'US'}
            </div>
            <div style={{ flex: 1 }}>
              <h3>{usuario?.nome || 'Usuário'}</h3>
              <p>{usuario?.email || 'email@exemplo.com'}</p>
            </div>
          </header>

          <form onSubmit={salvarPerfil} className="saas-perfil-form">
            <div className="saas-campo">
              <label className="saas-campo__label">Nome Completo</label>
              <input
                type="text"
                className="saas-campo__input"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                disabled={!editando || salvando}
              />
            </div>

            <div className="saas-campo">
              <label className="saas-campo__label">Endereço de E-mail</label>
              <input
                type="email"
                className="saas-campo__input"
                value={usuario?.email || ''}
                disabled
                title="O e-mail é a chave de login e não pode ser alterado diretamente."
              />
              <span className="saas-campo__dica">
                E-mail autenticado com cookie de sessão HTTP-Only protegido contra XSS.
              </span>
            </div>

            <div className="saas-campo">
              <label className="saas-campo__label">ID de Usuário no Sistema</label>
              <input
                type="text"
                className="saas-campo__input"
                value={`USR-${usuario?.id || 1}-PRO`}
                disabled
              />
            </div>

            <div className="saas-perfil-acoes" style={{ marginTop: '12px', display: 'flex', gap: '10px' }}>
              {editando ? (
                <>
                  <button type="submit" className="saas-botao saas-botao--primario" disabled={salvando}>
                    {salvando ? 'Salvando…' : 'Salvar Alterações'}
                  </button>
                  <button
                    type="button"
                    className="saas-botao saas-botao--secundario"
                    onClick={() => {
                      setNome(usuario?.nome || '')
                      setEditando(false)
                    }}
                  >
                    Cancelar
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  className="saas-botao saas-botao--secundario"
                  onClick={() => setEditando(true)}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
                  </svg>
                  <span>Editar Nome</span>
                </button>
              )}
            </div>
          </form>
        </section>

        {/* Card de Estatísticas do Usuário */}
        <section className="saas-card-config">
          <header className="saas-card-config__topo">
            <div className="saas-card-config__icone">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="18" x2="18" y1="20" y2="10" />
                <line x1="12" x2="12" y1="20" y2="4" />
                <line x1="6" x2="6" y1="20" y2="14" />
              </svg>
            </div>
            <div>
              <h3>Resumo Operacional da Conta</h3>
              <p>Métricas consolidadas do seu monitoramento contínuo de preços.</p>
            </div>
          </header>

          <div className="saas-canais-lista">
            <div className="saas-canal-item">
              <div className="saas-canal-item__info">
                <strong>Produtos Monitorados</strong>
                <p>Itens ativos vigiados pelos robôs de scraping</p>
              </div>
              <strong className="saas-kpi-destaque-num">{totalProdutos}</strong>
            </div>

            <div className="saas-canal-item">
              <div className="saas-canal-item__info">
                <strong>Oportunidades no Preço</strong>
                <p>Produtos que já alcançaram a sua meta de valor</p>
              </div>
              <strong className="saas-kpi-destaque-num" style={{ color: 'var(--saas-verde)' }}>
                {alvosAtingidos}
              </strong>
            </div>

            <div className="saas-canal-item">
              <div className="saas-canal-item__info">
                <strong>Alertas Disparados</strong>
                <p>Histórico total de notificações de queda geradas</p>
              </div>
              <strong className="saas-kpi-destaque-num">{totalAlertas}</strong>
            </div>

            <div className="saas-canal-item">
              <div className="saas-canal-item__info">
                <strong>Economia Acumulada</strong>
                <p>Retorno financeiro potencial detectado</p>
              </div>
              <strong className="saas-kpi-destaque-num" style={{ color: 'var(--saas-verde)' }}>
                {brl(economia)}
              </strong>
            </div>
          </div>

          <div className="saas-divisor" style={{ margin: '8px 0' }} />

          <div className="saas-zona-perigo">
            <h4>Sessão & Acesso</h4>
            <p style={{ fontSize: '12px', color: 'var(--saas-text-muted)', marginBottom: '10px' }}>
              Para alternar para outra conta ou encerrar o acesso:
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <button
                type="button"
                className="saas-botao saas-botao--secundario saas-botao--bloco"
                onClick={aoTrocarConta || aoSair}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
                <span>Trocar de Conta</span>
              </button>
              <button
                type="button"
                className="saas-botao saas-botao--secundario saas-botao--bloco"
                onClick={aoSair}
                style={{ color: 'var(--saas-vermelho)' }}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                  <polyline points="16 17 21 12 16 7" />
                  <line x1="21" y1="12" y2="12" />
                </svg>
                <span>Encerrar Sessão (Logout)</span>
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
